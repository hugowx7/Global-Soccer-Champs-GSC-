# GSC — Guia de design, referência e sistemas

Data de referência da pesquisa: **10 de novembro de 2026**.

## 1. Direção do produto

O GSC deve combinar:
- A simplicidade e o ritmo de um manager mobile: tabelas, elenco, escudos, simulação e participação manual nas chances.
- O lado de construção de clube de um modo Master League: decisões de gestão, transferências, evolução do projeto e narrativa fora de campo.
- A carreira individual: atleta criado pelo usuário, desenvolvimento, moral, forma, energia, relação com torcida e rivalidades.

A marca, a interface, os retratos e os sistemas são próprios do GSC. A meta é capturar a sensação do gênero, não duplicar telas, arte, código ou materiais de terceiros.

## 2. Referência atual: World Soccer Champs

A página do jogo na App Store descreve uma carreira longa, em que o usuário pode assumir clubes ou seleções, contratar e vender atletas, montar escalações, ganhar títulos, simular temporadas ou jogar momentos de ataque. Também descreve um mundo que evolui ao longo de muitas temporadas.

O histórico público consultado registra:
- **11.4 (2026):** potenciais dinâmicos, ranking dinâmico de países, torneios de treino, bônus de diretoria ao fim da temporada e tela de honrarias.
- **11.5 / 11.5.1:** Transfers 2.0, mais movimentação de mercado, clubes contratando conforme necessidades, revelações e evolução dos clubes ao longo das temporadas.
- **2026.12:** artilheiros e assistências de ligas estrangeiras importantes, desgaste afetando simulações/pulos de partida, novas opções de cabelo para goleiros e otimizações de memória/telas.

Fonte pública principal: https://apps.apple.com/us/app/world-soccer-champs/id1516548776

A ficha atual não explica a fórmula interna exata usada para calcular GER/força de setores, nem documenta todas as regras escondidas. Também não encontrei confirmação pública oficial, na versão atual consultada, de uma academia interativa com níveis 1/20 a 20/20 ou de um modo carreira de atleta completo dentro do WSC. Portanto, não há base pública confiável para afirmar que essas regras reproduzem a engine do WSC. A academia de 1–20, a carreira individual e a fórmula de setores são sistemas próprios do GSC.

## 3. Referência: Master League e carreira de atleta

A Konami descreve a Master League de PES 2021 como um modo single-player em que o usuário assume a gestão de um clube, com diálogos interativos, cenas, transferências e decisões dentro e fora de campo para desenvolver o clube.

Página oficial: https://www.konami.com/games/eu/en/products/pes2021/

O GSC aproveita a ideia de escolhas com consequências: confiança da diretoria, ambiente do vestiário, confiança da torcida, dívidas, imprensa, academia e planejamento de elenco.

## 4. Referência: EA SPORTS FC 27

A análise oficial de 31 de julho de 2026 descreve:
- Transferências com etapas, sondagem, autorização, negociação e opções contratuais.
- Valores que mudam ao longo da carreira.
- GER dinâmico conectado a fase, moral, condição física, lesões e minutos.
- Perfis de desenvolvimento com trajetórias diferentes.
- Várias posições possíveis para um atleta.
- Rivalidades na carreira de atleta, com objetivos baseados em desempenho.

A atualização oficial de 29 de setembro de 2026 menciona feedback sobre estamina e GER dinâmico, e ajustes em pedidos de transferência, tempo de jogo e empréstimos.

Fontes oficiais:
- https://www.ea.com/pt-br/games/ea-sports-fc/fc-27/news/pitch-notes-fc27-career-mode-deep-dive
- https://www.ea.com/games/ea-sports-fc/fc-27/news/fc-27-career-mode-developer-launch-update

## 5. Sistemas já colocados no protótipo GSC

### Carreira de técnico
- Escolher clube a partir dos dados incluídos.
- Calendário, campeonato de pontos corridos e classificação.
- Mercado funcional de compra e venda.
- Finanças e evolução do elenco.
- Simulação textual e chances de gol com controle por toque.

### Carreira de atleta — primeira versão
- Nome, posição, clube inicial e retrato procedural.
- GER base e GER dinâmico.
- Potencial, XP e crescimento por treino.
- Forma, moral, condição, energia e minutos.
- Estatísticas de aparições, gols e assistências.
- Lesão simples com dias de recuperação e tratamento por kit médico.
- É uma primeira camada simulada; ainda não controla um atleta individual em toda a partida 2D.

### Finanças e recursos gratuitos
- Moedas selecionáveis: real, dólar e euro.
- O valor-base da simulação é exibido conforme a moeda escolhida.
- Bux são obtidos por objetivos diários, vitórias e empates.
- Kits médicos e energia podem ser resgatados com Bux ganhos jogando.
- Empréstimo emergencial adiciona caixa, dívida e juros fixos de 8%.
- Amortização de dívida melhora a estabilidade e confiança da diretoria.

### Crise e redes sociais
- Indicadores separados para estabilidade financeira, confiança da diretoria, torcida e vestiário.
- Decisões de entrevista transparente, promessa de resultado e conversa com elenco.
- Feed offline criado pelos acontecimentos do save.
- Não existe postagem online ou comunicação entre jogadores.

### Academia e olheiros
- Academia, centro de treinamento e rede de olheiros com níveis de 1 a 20.
- Geração de jovens de 16 a 18 anos com GER e potencial estimados.
- Promoção de jovens adiciona o jogador ao banco local do clube da carreira de técnico.
- Os valores são gerados; não são atributos oficiais de atletas reais.

### Torneios personalizados
- Criação e gravação de ligas de pontos corridos com 8 a 32 clubes.
- Criação e gravação de copas mata-mata de 4 a 16 clubes, incluindo vagas automáticas para completar a chave.
- Nesta versão, o gerador cria a estrutura e o calendário/primeira fase; avançar os jogos personalizados ainda precisa ser integrado ao motor de partidas.

### Tática
Formações expostas no protótipo:
4-4-2, 4-3-3, 4-2-3-1, 4-5-1, 3-5-2, 3-4-3, 3-2-4-1, 3-3-1-3, 5-3-2, 5-4-1, 4-1-4-1, 4-3-2-1 e 4-1-2-1-2.

O protótipo calcula médias de defesa, meio-campo e ataque por posição agrupada. Em seguida aplica modificadores pequenos de formação, mentalidade e pressão. É uma regra própria do GSC e não uma suposta fórmula interna do WSC.

## 6. Aparência dos jogadores

Cada atleta recebe uma seed estável derivada do ID. O retrato é desenhado dentro do Godot com formas vetoriais e usa:
- Variações de tons de pele;
- Penteados curtos, degradê, cacheados, crespos, médios e raspados;
- Cores de cabelo;
- Sem barba, barba curta, cavanhaque, barba cheia e bigode;
- Cores diferentes de uniforme.

O objetivo é que os jogadores tenham rostos reconhecíveis entre sessões, sem baixar fotos reais sem licença. Os escudos do Data Pack são preservados no formato WebP enviado.

## 7. Economia e decisões

A dívida é um sistema separado do saldo do clube:
- Empréstimo emergencial aumenta o saldo do clube e registra principal + 8% na dívida.
- Amortizar dívida reduz o saldo disponível e aumenta a estabilidade financeira.
- Pagamentos semanais ainda são representados de forma simplificada por um acréscimo proporcional à folha registrada.
- Para um simulador econômico completo, a próxima fase deve usar receitas por bilheteria, patrocínio, premiações, vendas, salários, parcelas de transferências, impostos e juros compostos.

## 8. Próximas expansões recomendadas

1. Mercado em etapas: sondagem, autorização, proposta, contraproposta, contrato e apresentação.
2. Estatísticas completas de todas as ligas: gols, assistências, notas, cartões e histórico de competição.
3. Competições personalizadas: ligas de 8 a 32 clubes e copas eliminatórias de 4 a 16 clubes.
4. Modo carreira de atleta com escalação, minutos de jogo, objetivos da comissão, entrevistas, rivalidade e propostas de contrato.
5. Jogabilidade individual: controlar o avatar escolhido durante as chances 2D, e não apenas simular o desempenho.
6. Lesões e suspensões para todo o elenco, calendário médico e rotação.
7. Evolução do mundo: aposentadorias, geração de novos talentos, promoções/rebaixamentos e reputação dos clubes.
8. Interface mobile com retratos e escudos em listas, miniaturas e cache para reduzir uso de memória.
9. Testes automáticos com Godot headless em todas as cenas e principais sistemas.

## 9. Limites importantes

O Data Pack fornecido traz CSVs com pares de IDs e nomes. Não contém vínculo real jogador-clube, idade, posição, potencial, GER ou atributos. Esses campos são gerados deterministicamente para tornar o jogo testável. Os escudos enviados são WebP, não PNG.

O ZIP contém uma base técnica jogável em desenvolvimento. Não foi possível executar o motor Godot nesta sessão, porque o binário do Godot não está instalado no ambiente de criação. O workflow foi preparado para a validação e exportação em nuvem; a primeira execução no GitHub será a verificação de compilação real.
