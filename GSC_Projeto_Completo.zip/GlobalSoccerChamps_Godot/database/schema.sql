-- Esquema relacional de referência do Global Soccer Champs.
-- O APK usa o armazenamento JSON nativo do Godot para não depender de
-- GDExtension SQLite. Este SQL descreve as mesmas entidades para migração
-- futura, ferramenta externa ou backend SQLite.
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS countries (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    iso_code TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS competitions (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    competition_type TEXT NOT NULL DEFAULT 'league',
    country_id INTEGER REFERENCES countries(id)
);

CREATE TABLE IF NOT EXISTS leagues (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    competition_id INTEGER REFERENCES competitions(id),
    season INTEGER NOT NULL DEFAULT 2026,
    synthetic INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS clubs (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    league_id INTEGER REFERENCES leagues(id),
    reputation INTEGER NOT NULL DEFAULT 50,
    budget INTEGER NOT NULL DEFAULT 0,
    balance INTEGER NOT NULL DEFAULT 0,
    wage_limit INTEGER NOT NULL DEFAULT 0,
    logo_path TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS players (
    id INTEGER PRIMARY KEY,
    full_name TEXT NOT NULL,
    club_id INTEGER REFERENCES clubs(id),
    age INTEGER NOT NULL DEFAULT 18,
    position TEXT NOT NULL DEFAULT 'MID',
    overall INTEGER NOT NULL DEFAULT 40,
    potential INTEGER NOT NULL DEFAULT 60,
    market_value INTEGER NOT NULL DEFAULT 0,
    weekly_salary INTEGER NOT NULL DEFAULT 0,
    attributes_source TEXT NOT NULL DEFAULT 'estimated'
);

CREATE TABLE IF NOT EXISTS club_rosters (
    club_id INTEGER NOT NULL REFERENCES clubs(id) ON DELETE CASCADE,
    player_id INTEGER NOT NULL UNIQUE REFERENCES players(id) ON DELETE CASCADE,
    shirt_number INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (club_id, player_id)
);

CREATE TABLE IF NOT EXISTS fixtures (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    league_id INTEGER NOT NULL REFERENCES leagues(id),
    season INTEGER NOT NULL DEFAULT 2026,
    round_number INTEGER NOT NULL,
    home_club_id INTEGER NOT NULL REFERENCES clubs(id),
    away_club_id INTEGER NOT NULL REFERENCES clubs(id),
    home_goals INTEGER,
    away_goals INTEGER,
    status TEXT NOT NULL DEFAULT 'scheduled'
);

CREATE TABLE IF NOT EXISTS league_standings (
    league_id INTEGER NOT NULL REFERENCES leagues(id),
    club_id INTEGER NOT NULL REFERENCES clubs(id),
    played INTEGER NOT NULL DEFAULT 0,
    wins INTEGER NOT NULL DEFAULT 0,
    draws INTEGER NOT NULL DEFAULT 0,
    losses INTEGER NOT NULL DEFAULT 0,
    goals_for INTEGER NOT NULL DEFAULT 0,
    goals_against INTEGER NOT NULL DEFAULT 0,
    points INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (league_id, club_id)
);

CREATE TABLE IF NOT EXISTS transfers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    player_id INTEGER NOT NULL REFERENCES players(id),
    from_club_id INTEGER REFERENCES clubs(id),
    to_club_id INTEGER NOT NULL REFERENCES clubs(id),
    fee INTEGER NOT NULL DEFAULT 0,
    season INTEGER NOT NULL,
    transfer_date TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS finances (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    club_id INTEGER NOT NULL REFERENCES clubs(id),
    season INTEGER NOT NULL,
    category TEXT NOT NULL,
    amount INTEGER NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS app_meta (
    meta_key TEXT PRIMARY KEY,
    meta_value TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_players_club ON players(club_id);
CREATE INDEX IF NOT EXISTS idx_players_position_rating ON players(position, overall DESC);
CREATE INDEX IF NOT EXISTS idx_rosters_club ON club_rosters(club_id);
CREATE INDEX IF NOT EXISTS idx_fixtures_round ON fixtures(league_id, season, round_number);
CREATE INDEX IF NOT EXISTS idx_standings_points ON league_standings(league_id, points DESC);

CREATE VIEW IF NOT EXISTS club_roster_details AS
SELECT c.id AS club_id, c.name AS club_name, p.id AS player_id,
       p.full_name, p.age, p.position, p.overall AS skill,
       p.potential, p.market_value, p.weekly_salary
FROM clubs c
JOIN players p ON p.club_id = c.id;
