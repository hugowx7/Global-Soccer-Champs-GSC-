Data Pack fornecido pelo usuário: pro_datapack_v86.zip.
Arquivos CSV são pares id,nome sem cabeçalho.
Club logos e competition logos foram mantidos no formato WebP original.
O projeto não inclui a pasta adboards para reduzir o tamanho do APK.
Veja docs/DATA_PACK_REPORT.json para contagens e campos sintéticos.
