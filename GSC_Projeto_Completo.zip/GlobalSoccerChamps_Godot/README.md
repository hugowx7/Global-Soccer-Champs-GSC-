# Global Soccer Champs (GSC)

Manager de futebol mobile feito em Godot 4. O projeto combina carreira de técnico, uma primeira versão de carreira de atleta, mercado, tabela, partidas com chances controladas por toque, academia, finanças, redes sociais e retratos procedurais originais.

## Identidade

- Nome no Android: **Global Soccer Champs**
- Sigla: **GSC**
- Pacote Android: `br.com.globalsoccerchamps.game`
- APK: `GlobalSoccerChamps.apk`
- Projeto: Godot 4.3+ (workflow usa Godot 4.7.2)
- Renderizador: Compatibility / OpenGL ES

## Conteúdo incluído

- 4.122 clubes, 67.932 nomes de jogadores, 94 competições, 3.284 estádios e 4.133 escudos do Data Pack enviado.
- Escudos preservados em WebP dentro de `datapack/club_logos/`.
- Banco JSON nativo para não depender de uma extensão SQLite/GDExtension Android.
- Tabela de pontos corridos, calendário, mercado, compra e venda de atletas, evolução, finanças e save local.
- Partida simulada em texto com oportunidades que abrem o campo 2D e controles de toque.
- Carreira de atleta inicial: criação, clube inicial, posição, treinos, XP, GER dinâmico, forma, moral, condição, energia, partidas, gols, assistências e lesões simples.
- Academia nível 1–20, jovens gerados, centro de treinamento, olheiros e promoção de jovens ao elenco.
- Finanças: BRL / USD / EUR, Bux gratuitos, kits médicos, energia, dívidas, empréstimo emergencial, confiança da diretoria e torcida.
- Feed de notícias/rede social interno com decisões de imprensa, diretoria e vestiário.
- Formações, mentalidade e pressão; modificadores táticos próprios do GSC.
- Criação e salvamento de ligas personalizadas (8–32 clubes) e copas mata-mata (4–16 clubes), com calendário/primeira fase gerados.
- Retratos procedurais com variações de pele, cabelo, penteado, barba e uniforme.
- Workflow de compilação Android no GitHub Actions.

## Dados do Data Pack

Os CSVs recebidos trazem pares `id,nome`. Eles não incluem a relação real de cada jogador com seu clube, nem idade, posição, habilidades ou potencial. O GSC gera esses campos ausentes por regras determinísticas e marca a origem como estimativa. Não trate esses atributos como dados oficiais.

Os escudos foram enviados em WebP, portanto foram mantidos em WebP em vez de convertidos para PNG. O projeto carrega esses arquivos sem conversão manual.

## Como enviar pelo celular e compilar

**Importante:** subir apenas um ZIP não registra automaticamente um workflow no GitHub. O GitHub só reconhece o robô quando o YAML está em `.github/workflows/build_android.yml` na raiz do repositório.

1. Crie um repositório vazio no GitHub.
2. Baixe `GlobalSoccerChamps_Godot_Source.zip` e envie esse ZIP para a raiz do repositório (`Add file` → `Upload files` → `Commit changes`).
3. No repositório, abra `Add file` → `Create new file`.
4. No nome do arquivo, escreva exatamente `.github/workflows/build_android.yml`.
5. Abra o arquivo `GSC_build_android.yml` que acompanha a entrega, copie todo o conteúdo e cole no editor do GitHub.
6. Confirme em `Commit changes`.
7. Abra a aba `Actions`, selecione `Build Android APK` e use `Run workflow` se o push não iniciar automaticamente.
8. Ao terminar, abra a execução verde e baixe `Global-Soccer-Champs-Android-APK` em `Artifacts`. Extraia o ZIP baixado para encontrar `GlobalSoccerChamps.apk`.

O workflow extrai o ZIP da raiz, instala Java 17, Android SDK e os Export Templates do Godot, gera uma `debug.keystore` temporária e exporta o APK.

## Abrir localmente (opcional)

Abra `project.godot` no Godot 4.3 ou superior. A cena inicial é `res://scenes/main.tscn`. A interface é construída por código; não é necessário montar nós manualmente.

## Limitações conhecidas desta versão

- É uma base jogável em desenvolvimento, não um jogo final com a quantidade de animações, áudio, conteúdo e polimento de um produto comercial.
- A carreira de atleta possui simulação de aparições e evolução; ainda não é uma partida 2D contínua controlando apenas um jogador.
- O feed social é offline e gerado pelo jogo; não é uma rede social online real.
- O mercado atual mantém o fluxo funcional de compra/venda do protótipo. Negociações em várias etapas, cláusulas e IA global mais profunda são expansão futura.
- Não há sincronização em nuvem nem modo online.
- As tabelas e divisões geradas a partir do CSV são estruturas sintéticas; os arquivos recebidos não especificam a distribuição real dos clubes por liga.
- O APK do workflow é de depuração (debug), adequado para teste e instalação manual, não é uma assinatura de publicação permanente na Play Store.

## Pesquisa usada como referência de design

- World Soccer Champs — página oficial da App Store e histórico de versões: https://apps.apple.com/us/app/world-soccer-champs/id1516548776
- EA SPORTS FC 27 — análise oficial do Modo Carreira: https://www.ea.com/pt-br/games/ea-sports-fc/fc-27/news/pitch-notes-fc27-career-mode-deep-dive
- EA SPORTS FC 27 — atualização oficial pós-lançamento do Modo Carreira: https://www.ea.com/games/ea-sports-fc/fc-27/news/fc-27-career-mode-developer-launch-update
- Konami — eFootball PES 2021, modos de jogo e Master League: https://www.konami.com/games/eu/en/products/pes2021/

O GSC é um projeto original inspirado no gênero de jogos de manager de futebol. Não usa código, interface, nomes de menus ou artes extraídas dos jogos citados.
