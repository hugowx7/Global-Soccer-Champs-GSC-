extends Node
class_name GeradorBancoDados

## Banco de dados portátil do Global Soccer Champs.
## O Data Pack fornecido contém IDs e nomes, mas não possui clube atual,
## idade, posição, habilidade ou potencial. Os campos ausentes são gerados
## deterministicamente e ficam marcados como estimativas no metadata.
## O jogo usa JSON nativo para não depender de uma extensão SQLite/GDExtension.

signal banco_pronto(resultado: Dictionary)
signal progresso(etapa: String, atual: int, total: int)

const CACHE_PATH := "user://manager_database.json"
const PACK_ROOT := "res://datapack"
const DATABASE_VERSION := 3
const ROLE_SEQUENCE := [
	"GK", "GK",
	"DEF", "DEF", "DEF", "DEF", "DEF",
	"MID", "MID", "MID", "MID", "MID",
	"ATT", "ATT", "ATT", "ATT"
]

var database_data: Dictionary = {}
var _club_by_id: Dictionary = {}
var _player_index_by_id: Dictionary = {}
var _roster_indexes: Dictionary = {}
var _rng := RandomNumberGenerator.new()

func _ready() -> void:
	_rng.randomize()

func initialize_database() -> Dictionary:
	var clubs_path := PACK_ROOT.path_join("clubs.csv")
	var players_path := PACK_ROOT.path_join("players.csv")
	var competitions_path := PACK_ROOT.path_join("competitions.csv")
	var stadiums_path := PACK_ROOT.path_join("stadiums.csv")

	if not FileAccess.file_exists(clubs_path) or not FileAccess.file_exists(players_path):
		var missing := {"ok": false, "error": "Data Pack não encontrado dentro do APK (res://datapack)."}
		banco_pronto.emit(missing)
		return missing

	progresso.emit("Verificando Data Pack", 0, 1)
	var clubs_text := FileAccess.get_file_as_string(clubs_path)
	var players_text := FileAccess.get_file_as_string(players_path)
	var competitions_text := FileAccess.get_file_as_string(competitions_path) if FileAccess.file_exists(competitions_path) else ""
	var stadiums_text := FileAccess.get_file_as_string(stadiums_path) if FileAccess.file_exists(stadiums_path) else ""
	var signature := "%s:%s:%s:%s" % [str(clubs_text.hash()), str(players_text.hash()), str(competitions_text.hash()), str(stadiums_text.hash())]

	var cached := _load_cache(signature)
	if cached:
		_rebuild_indexes()
		var cached_result := _result_dictionary(false, "Banco carregado do armazenamento local.")
		banco_pronto.emit(cached_result)
		return cached_result

	var club_pairs := _parse_pairs(clubs_text)
	var player_pairs := _parse_pairs(players_text)
	var competition_pairs := _parse_pairs(competitions_text)
	var stadium_pairs := _parse_pairs(stadiums_text)
	if club_pairs.is_empty() or player_pairs.is_empty():
		var invalid := {"ok": false, "error": "Os CSVs de clubes ou jogadores estão vazios ou inválidos."}
		banco_pronto.emit(invalid)
		return invalid

	var clubs: Array = []
	var total_clubs := club_pairs.size()
	var league_count := maxi(1, ceili(float(total_clubs) / 20.0))
	for i in range(total_clubs):
		var source: Dictionary = club_pairs[i]
		var club_id := int(source["id"])
		var league_id := int(floor(float(i) * float(league_count) / float(total_clubs))) + 1
		var reputation := 42 + (_mix(club_id * 13 + 71) % 43)
		var budget := 350000 + reputation * reputation * 1800
		var logo_path := "res://datapack/club_logos/%d.webp" % club_id
		if not ResourceLoader.exists(logo_path):
			logo_path = ""
		clubs.append({
			"id": club_id,
			"name": str(source["name"]),
			"league_id": league_id,
			"reputation": reputation,
			"budget": budget,
			"balance": budget,
			"wage_limit": maxi(500000, int(budget / 10.0)),
			"logo_path": logo_path
		})
		if i % 500 == 0:
			progresso.emit("Importando clubes", i, total_clubs)
			await get_tree().process_frame

	var players: Array = []
	var total_players := player_pairs.size()
	for i in range(total_players):
		var source_player: Dictionary = player_pairs[i]
		var player_id := int(source_player["id"])
		var club_index := i % clubs.size()
		var club: Dictionary = clubs[club_index]
		var club_id := int(club["id"])
		var slot := int(i / clubs.size())
		var position := str(ROLE_SEQUENCE[slot]) if slot < ROLE_SEQUENCE.size() else "MID"
		var age := 16 + (_mix(player_id * 11 + club_id * 5) % 20)
		var noise := (_mix(player_id * 31 + club_id * 17) % 23) - 11
		var rating := clampi(34 + int(int(club["reputation"]) * 0.49) + noise, 38, 89)
		var age_penalty := maxi(0, age - 28) / 2
		var potential_bonus := 3 + (_mix(player_id * 97 + 19) % 19) - age_penalty
		var potential := clampi(rating + potential_bonus, rating, 96)
		var age_factor := maxf(0.38, 1.0 - absf(float(age - 24)) * 0.025)
		var market_value := maxi(18000, int(pow(float(rating), 2.5) * 78.0 * age_factor))
		var weekly_salary := maxi(250, int(market_value / 90.0))
		# Formato compacto: [id, nome, clube, idade, posição, habilidade,
		# potencial, valor de mercado, salário semanal].
		players.append([
			player_id,
			str(source_player["name"]),
			club_id,
			age,
			position,
			rating,
			potential,
			market_value,
			weekly_salary
		])
		if i % 2500 == 0:
			progresso.emit("Gerando elencos e atributos estimados", i, total_players)
			await get_tree().process_frame

	var competitions: Array = []
	for row in competition_pairs:
		competitions.append({"id": int(row["id"]), "name": str(row["name"])})
	var stadiums: Array = []
	for row in stadium_pairs:
		stadiums.append({"id": int(row["id"]), "name": str(row["name"])})

	database_data = {
		"meta": {
			"version": DATABASE_VERSION,
			"signature": signature,
			"generated_at": Time.get_datetime_string_from_system(true),
			"assignment_type": "synthetic_round_robin",
			"attributes_type": "deterministic_estimates",
			"clubs_count": clubs.size(),
			"players_count": players.size(),
			"competitions_count": competitions.size(),
			"stadiums_count": stadiums.size()
		},
		"clubs": clubs,
		"players": players,
		"competitions": competitions,
		"stadiums": stadiums
	}
	_rebuild_indexes()
	var saved := save_database()
	var result := _result_dictionary(true, "Importação concluída. Os vínculos e atributos são estimativas geradas pelo jogo.")
	result["saved"] = saved
	banco_pronto.emit(result)
	return result

func _load_cache(signature: String) -> bool:
	if not FileAccess.file_exists(CACHE_PATH):
		return false
	var file := FileAccess.open(CACHE_PATH, FileAccess.READ)
	if file == null:
		return false
	var parsed: Variant = JSON.parse_string(file.get_as_text())
	file.close()
	if not parsed is Dictionary:
		return false
	var meta: Dictionary = parsed.get("meta", {})
	if int(meta.get("version", 0)) != DATABASE_VERSION or str(meta.get("signature", "")) != signature:
		return false
	if not parsed.has("clubs") or not parsed.has("players"):
		return false
	if parsed["clubs"].size() == 0 or parsed["players"].size() == 0:
		return false
	database_data = parsed
	return true

func save_database() -> bool:
	if database_data.is_empty():
		return false
	var file := FileAccess.open(CACHE_PATH, FileAccess.WRITE)
	if file == null:
		push_error("Não foi possível gravar o banco: " + str(FileAccess.get_open_error()))
		return false
	file.store_string(JSON.stringify(database_data))
	file.close()
	return true

func _parse_pairs(csv_text: String) -> Array:
	var result: Array = []
	for raw_line in csv_text.split("\n", false):
		var line := str(raw_line).strip_edges().trim_prefix("\uFEFF")
		if line.is_empty():
			continue
		var comma := line.find(",")
		if comma <= 0:
			continue
		var id_text := line.substr(0, comma).strip_edges()
		if not id_text.is_valid_int():
			continue
		var display_name := line.substr(comma + 1).strip_edges().trim_prefix("\"").trim_suffix("\"")
		if display_name.is_empty():
			continue
		result.append({"id": id_text.to_int(), "name": display_name})
	return result

func _mix(value: int) -> int:
	var mixed := int(posmod(value * 1103515245 + 12345, 2147483647))
	mixed = int(posmod(mixed * 48271 + 1, 2147483647))
	return mixed

func _rebuild_indexes() -> void:
	_club_by_id.clear()
	_player_index_by_id.clear()
	_roster_indexes.clear()
	for club_variant in database_data.get("clubs", []):
		var club: Dictionary = club_variant
		_club_by_id[str(int(club["id"]))] = club
		_roster_indexes[str(int(club["id"]))] = []
	var players: Array = database_data.get("players", [])
	for i in range(players.size()):
		var row: Array = players[i]
		var player_id := int(row[0])
		var club_id := int(row[2])
		_player_index_by_id[str(player_id)] = i
		var key := str(club_id)
		if not _roster_indexes.has(key):
			_roster_indexes[key] = []
		_roster_indexes[key].append(i)

func _result_dictionary(generated: bool, message: String) -> Dictionary:
	var meta: Dictionary = database_data.get("meta", {})
	return {
		"ok": true,
		"generated": generated,
		"clubs": int(meta.get("clubs_count", 0)),
		"players": int(meta.get("players_count", 0)),
		"roster_links": int(meta.get("players_count", 0)),
		"competitions": int(meta.get("competitions_count", 0)),
		"stadiums": int(meta.get("stadiums_count", 0)),
		"message": message
	}

func get_clubs() -> Array:
	return database_data.get("clubs", [])

func get_club(club_id: int) -> Dictionary:
	return _club_by_id.get(str(club_id), {}).duplicate(true)

func get_clubs_for_league(league_id: int) -> Array:
	var result: Array = []
	for club_variant in database_data.get("clubs", []):
		var club: Dictionary = club_variant
		if int(club.get("league_id", 0)) == league_id:
			result.append(club.duplicate(true))
	return result

func search_clubs(query: String, limit: int = 40) -> Array:
	var result: Array = []
	var normalized := query.strip_edges().to_lower()
	for club_variant in database_data.get("clubs", []):
		var club: Dictionary = club_variant
		if normalized.is_empty() or str(club.get("name", "")).to_lower().contains(normalized):
			result.append(club.duplicate(true))
			if result.size() >= limit:
				break
	return result

func get_roster(club_id: int) -> Array:
	var result: Array = []
	var indexes: Array = _roster_indexes.get(str(club_id), [])
	var players: Array = database_data.get("players", [])
	for index_variant in indexes:
		var row: Array = players[int(index_variant)]
		result.append(_player_from_row(row))
	return result

func get_player_by_id(player_id: int) -> Dictionary:
	if not _player_index_by_id.has(str(player_id)):
		return {}
	var index := int(_player_index_by_id[str(player_id)])
	return _player_from_row(database_data["players"][index])

func _player_from_row(row: Array) -> Dictionary:
	return {
		"id": int(row[0]),
		"name": str(row[1]),
		"club_id": int(row[2]),
		"age": int(row[3]),
		"position": str(row[4]),
		"overall": int(row[5]),
		"potential": int(row[6]),
		"market_value": int(row[7]),
		"weekly_salary": int(row[8])
	}

func get_market_players(excluded_club_id: int, count: int = 30) -> Array:
	var result: Array = []
	var players: Array = database_data.get("players", [])
	if players.is_empty():
		return result
	var used: Dictionary = {}
	var attempts := 0
	while result.size() < count and attempts < count * 25:
		attempts += 1
		var index := _rng.randi_range(0, players.size() - 1)
		var row: Array = players[index]
		var player_id := int(row[0])
		if int(row[2]) == excluded_club_id or used.has(str(player_id)):
			continue
		used[str(player_id)] = true
		result.append(_player_from_row(row))
	result.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
		return int(a["overall"]) > int(b["overall"])
	)
	return result

func transfer_player(player_id: int, destination_club_id: int) -> bool:
	if not _player_index_by_id.has(str(player_id)) or not _club_by_id.has(str(destination_club_id)):
		return false
	var index := int(_player_index_by_id[str(player_id)])
	database_data["players"][index][2] = destination_club_id
	_rebuild_indexes()
	return save_database()

func update_player_rating(player_id: int, new_rating: int) -> bool:
	if not _player_index_by_id.has(str(player_id)):
		return false
	var index := int(_player_index_by_id[str(player_id)])
	var row: Array = database_data["players"][index]
	row[5] = clampi(new_rating, 1, 99)
	row[6] = maxi(int(row[6]), int(row[5]))
	row[7] = maxi(1000, int(pow(float(row[5]), 2.5) * 78.0))
	row[8] = maxi(100, int(int(row[7]) / 90))
	return save_database()

func get_competitions() -> Array:
	return database_data.get("competitions", [])

func get_stadiums() -> Array:
	return database_data.get("stadiums", [])

func get_logo_texture(club_id: int) -> Texture2D:
	var club := get_club(club_id)
	var path := str(club.get("logo_path", ""))
	if path.is_empty() or not ResourceLoader.exists(path):
		return null
	var loaded: Resource = load(path)
	return loaded as Texture2D

## Compatibilidade com o nome usado nos scripts anteriores.
func criar_tabela_rosters() -> bool:
	return FileAccess.file_exists("res://database/schema.sql")

func vincular_e_gerar_atributos() -> Dictionary:
	return await initialize_database()

func inicializar_banco() -> Dictionary:
	return await initialize_database()

func add_generated_player(player: Dictionary, club_id: int) -> bool:
	var name := str(player.get("name", "Jovem da Base"))
	var position := str(player.get("position", "MID"))
	var player_id := int(player.get("id", 0))
	if player_id <= 0 or _player_index_by_id.has(str(player_id)):
		var max_id := 1
		for row_variant in database_data.get("players", []):
			var row: Array = row_variant
			max_id = maxi(max_id, int(row[0]))
		player_id = max_id + 1
	var overall := clampi(int(player.get("overall", 40)), 1, 99)
	var potential := clampi(int(player.get("potential", overall + 10)), overall, 99)
	var market_value := maxi(1000, int(pow(float(overall), 2.5) * 78.0))
	var salary := maxi(100, int(market_value / 90.0))
	var rows: Array = database_data.get("players", [])
	rows.append([
		player_id, name, club_id, clampi(int(player.get("age", 17)), 15, 20),
		position, overall, potential, market_value, salary
	])
	database_data["players"] = rows
	var meta: Dictionary = database_data.get("meta", {})
	meta["players_count"] = rows.size()
	database_data["meta"] = meta
	_rebuild_indexes()
	return save_database()
