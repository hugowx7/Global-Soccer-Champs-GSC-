extends Node2D
class_name GoalkeeperAI

@export var reaction_speed := 390.0
@export var vertical_limit := 118.0

var goal_center := Vector2(1160.0, 360.0)
var predicted_shot_y := 360.0
var active := false

func set_context(_ball_position: Vector2, center: Vector2, predicted_y: float) -> void:
	goal_center = center
	predicted_shot_y = predicted_y
	active = true

func reset_position() -> void:
	active = false
	global_position = goal_center

func _physics_process(delta: float) -> void:
	if not active:
		return
	var target_y := clampf(predicted_shot_y, goal_center.y - vertical_limit, goal_center.y + vertical_limit)
	var target := Vector2(goal_center.x, target_y)
	global_position = global_position.move_toward(target, reaction_speed * delta)

func _draw() -> void:
	draw_rect(Rect2(Vector2(-10.0, -22.0), Vector2(20.0, 44.0)), Color("#f4c542"), true)
	draw_circle(Vector2(0.0, -28.0), 10.0, Color("#f1c7a4"))
