extends Node2D
class_name SwipeMatchInput

## Arraste curto/médio seleciona um passe; arraste longo na direção do gol chuta.
## Entrada por toque é usada no Android e mouse apenas para testes desktop.

signal action_requested(action: Dictionary)

@export var tap_deadzone_px := 22.0
@export var shot_min_length_px := 100.0
@export var attacking_direction := Vector2.RIGHT
@export var goal_position := Vector2(1160.0, 360.0)

var ball: BallPhysics
var allies: Array[Node2D] = []
var _tracking := false
var _start_local := Vector2.ZERO
var _current_local := Vector2.ZERO
var _raw_drag := Vector2.ZERO
var input_enabled := true

func configure(ball_node: BallPhysics, ally_nodes: Array[Node2D], goal: Vector2, attack_dir: Vector2) -> void:
	ball = ball_node
	allies = ally_nodes
	goal_position = goal
	attacking_direction = attack_dir.normalized()

func set_input_enabled(enabled: bool) -> void:
	input_enabled = enabled
	if not enabled:
		_tracking = false
	queue_redraw()

func _unhandled_input(event: InputEvent) -> void:
	if not input_enabled:
		return
	if event is InputEventScreenTouch:
		var touch := event as InputEventScreenTouch
		if touch.index != 0:
			return
		if touch.pressed:
			_begin_gesture(touch.position)
		else:
			_finish_gesture(touch.position)
		get_viewport().set_input_as_handled()
		return
	if event is InputEventScreenDrag:
		var drag := event as InputEventScreenDrag
		if _tracking:
			_current_local = _to_local(drag.position)
			_raw_drag += drag.relative
			queue_redraw()
		get_viewport().set_input_as_handled()
		return
	if not OS.has_feature("android") and not OS.has_feature("ios"):
		if event is InputEventMouseButton and (event as InputEventMouseButton).button_index == MOUSE_BUTTON_LEFT:
			var mouse_button := event as InputEventMouseButton
			if mouse_button.pressed:
				_begin_gesture(mouse_button.position)
			else:
				_finish_gesture(mouse_button.position)
			get_viewport().set_input_as_handled()
		elif event is InputEventMouseMotion and _tracking:
			var mouse_motion := event as InputEventMouseMotion
			_current_local = _to_local(mouse_motion.position)
			_raw_drag = _current_local - _start_local
			queue_redraw()
			get_viewport().set_input_as_handled()

func _begin_gesture(viewport_position: Vector2) -> void:
	_tracking = true
	_start_local = _to_local(viewport_position)
	_current_local = _start_local
	_raw_drag = Vector2.ZERO
	queue_redraw()

func _finish_gesture(viewport_position: Vector2) -> void:
	if not _tracking:
		return
	_current_local = _to_local(viewport_position)
	if _raw_drag.length() < 0.01:
		_raw_drag = _current_local - _start_local
	_tracking = false
	queue_redraw()
	var drag_length := _raw_drag.length()
	if drag_length < tap_deadzone_px:
		action_requested.emit({"type": "tap", "position": _current_local})
		return
	var direction := _raw_drag.normalized()
	var strength := clampf(drag_length / 260.0, 0.18, 1.0)
	var goal_direction := (goal_position - ball.global_position).normalized() if is_instance_valid(ball) else attacking_direction
	var toward_goal := direction.dot(goal_direction) >= 0.55
	if drag_length >= shot_min_length_px and toward_goal:
		chutar_bola(direction, strength)
	else:
		passar_bola(direction, strength)

func passar_bola(direction: Vector2, power: float = 0.65) -> void:
	if not is_instance_valid(ball):
		return
	var receiver := _find_receiver(direction)
	if receiver == null:
		ball.kick(direction, power, false)
		action_requested.emit({"type": "pass", "direction": direction, "power": power, "receiver_id": -1, "receiver_position": ball.global_position + direction * 160.0})
		return
	ball.pass_to(receiver)
	action_requested.emit({
		"type": "pass",
		"direction": direction,
		"power": power,
		"receiver_id": int(receiver.get_meta("player_id", -1)),
		"receiver_position": receiver.global_position
	})

func chutar_bola(direction: Vector2, power: float) -> void:
	if not is_instance_valid(ball):
		return
	ball.kick(direction, power, true)
	set_input_enabled(false)
	action_requested.emit({"type": "shoot", "direction": direction, "power": power})

func _find_receiver(direction: Vector2) -> Node2D:
	if not is_instance_valid(ball):
		return null
	var best: Node2D = null
	var best_score := INF
	for ally in allies:
		if not is_instance_valid(ally):
			continue
		var offset := ally.global_position - ball.global_position
		var distance := offset.length()
		if distance < 28.0:
			continue
		var alignment := direction.normalized().dot(offset.normalized())
		if alignment < -0.15:
			continue
		var score := distance * (1.25 - clampf(alignment, -1.0, 1.0) * 0.45)
		if score < best_score:
			best_score = score
			best = ally
	return best

func _to_local(viewport_position: Vector2) -> Vector2:
	return get_global_transform_with_canvas().affine_inverse() * viewport_position

func _draw() -> void:
	if not _tracking:
		return
	draw_line(_start_local, _current_local, Color("#fff5a5"), 5.0, true)
	var direction := _current_local - _start_local
	if direction.length() > 10.0:
		var unit := direction.normalized()
		var side := unit.rotated(PI * 0.78) * 18.0
		draw_line(_current_local, _current_local - unit * 25.0 + side, Color("#fff5a5"), 5.0, true)
		draw_line(_current_local, _current_local - unit * 25.0 - side, Color("#fff5a5"), 5.0, true)
