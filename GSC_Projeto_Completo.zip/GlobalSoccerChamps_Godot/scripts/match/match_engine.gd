extends RefCounted
class_name MatchEngine

## Simulação em texto. Quando o time controlado cria uma chance, o estado
## entra em pausa até a finalização manual no campo 2D.

var rng := RandomNumberGenerator.new()

func _init() -> void:
	rng.randomize()

func create_match(home_team: Dictionary, away_team: Dictionary, user_team_id: int, fixture_id: int) -> Dictionary:
	return {
		"minute": 0,
		"home_goals": 0,
		"away_goals": 0,
		"home_shots": 0,
		"away_shots": 0,
		"home_team_id": int(home_team.get("id", 0)),
		"away_team_id": int(away_team.get("id", 0)),
		"user_team_id": user_team_id,
		"fixture_id": fixture_id,
		"finished": false,
		"manual_pending": false,
		"pending_quality": 0.45,
		"last_event": "Apito inicial!"
	}

func simulate_minute(home_team: Dictionary, away_team: Dictionary, state: Dictionary, user_team_id: int) -> Dictionary:
	var next_state := state.duplicate(true)
	if bool(next_state.get("finished", false)):
		return {"state": next_state, "event": {"type": "finished", "text": "Partida encerrada."}}
	if bool(next_state.get("manual_pending", false)):
		return {"state": next_state, "event": {"type": "manual_chance", "text": "Finalize a chance no campo 2D."}}

	var minute := mini(90, int(next_state.get("minute", 0)) + 1)
	next_state["minute"] = minute
	if minute >= 90 and rng.randf() < 0.55:
		next_state["finished"] = true
		return {"state": next_state, "event": {"type": "finished", "text": "Fim de jogo."}}

	var home_attacks := rng.randf() < 0.5
	var attacking_team: Dictionary = home_team if home_attacks else away_team
	var defending_team: Dictionary = away_team if home_attacks else home_team
	var attacking_id := int(attacking_team.get("id", 0))
	var attack_rating := float(attacking_team.get("attack", 55.0)) * 0.65 + float(attacking_team.get("midfield", 55.0)) * 0.35
	var defence_rating := float(defending_team.get("defence", 55.0))
	var chance_probability := clampf(0.10 + (attack_rating - defence_rating + 25.0) * 0.004, 0.07, 0.25)
	if rng.randf() >= chance_probability:
		return {"state": next_state, "event": {}}

	var shot_key := "home_shots" if home_attacks else "away_shots"
	next_state[shot_key] = int(next_state.get(shot_key, 0)) + 1
	if attacking_id == user_team_id:
		var quality := clampf(0.38 + (attack_rating - defence_rating) * 0.006, 0.18, 0.86)
		next_state["manual_pending"] = true
		next_state["pending_quality"] = quality
		next_state["pending_is_home"] = home_attacks
		next_state["last_event"] = "Chance de gol! Arraste para passar ou chutar."
		return {
			"state": next_state,
			"event": {
				"type": "manual_chance",
				"team_id": attacking_id,
				"quality": quality,
				"is_home": home_attacks,
				"text": "CHANCE DE GOL! O jogo está pausado para o controle manual."
			}
		}

	var goalkeeper := float(defending_team.get("goalkeeper", 55.0))
	var goal_probability := clampf(0.12 + (attack_rating - goalkeeper) * 0.006, 0.04, 0.42)
	var scored := rng.randf() < goal_probability
	if scored:
		var goal_key := "home_goals" if home_attacks else "away_goals"
		next_state[goal_key] = int(next_state.get(goal_key, 0)) + 1
	var event_text := "Gol do adversário!" if scored else "Finalização defendida pelo goleiro."
	next_state["last_event"] = event_text
	return {"state": next_state, "event": {"type": "ai_goal" if scored else "ai_shot", "team_id": attacking_id, "text": event_text}}

func resolve_manual_shot(state: Dictionary, attack_quality: float, shot_skill: float, keeper_skill: float, attacking_is_home: bool = true, power: float = 0.7) -> Dictionary:
	var updated := state.duplicate(true)
	var quality := clampf(attack_quality, 0.0, 1.0)
	var technique := clampf(shot_skill / 100.0, 0.0, 1.0)
	var keeper := clampf(keeper_skill / 100.0, 0.0, 1.0)
	var power_factor := clampf(power, 0.15, 1.0)
	var probability := clampf(0.06 + quality * 0.32 + technique * 0.25 + power_factor * 0.12 - keeper * 0.21, 0.03, 0.74)
	var goal := rng.randf() < probability
	if goal:
		var goal_key := "home_goals" if attacking_is_home else "away_goals"
		updated[goal_key] = int(updated.get(goal_key, 0)) + 1
	updated["manual_pending"] = false
	updated["last_event"] = "GOLAÇO!" if goal else "A finalização não entrou."
	return {
		"state": updated,
		"event": {"type": "goal" if goal else "saved_or_missed", "goal": goal, "text": str(updated["last_event"])}
	}

func cancel_manual_chance(state: Dictionary) -> Dictionary:
	var updated := state.duplicate(true)
	updated["manual_pending"] = false
	updated["last_event"] = "A jogada foi desperdiçada."
	return {"state": updated, "event": {"type": "missed", "text": "A jogada foi desperdiçada."}}
