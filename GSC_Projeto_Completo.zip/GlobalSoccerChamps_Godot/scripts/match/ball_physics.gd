extends Node2D
class_name BallPhysics

@export var pass_speed := 520.0
@export var shot_speed := 900.0
@export var friction := 430.0
@export var gravity := 760.0

var velocity := Vector2.ZERO
var height := 0.0
var height_velocity := 0.0
var is_moving := false

func pass_to(target: Node2D) -> void:
	if not is_instance_valid(target):
		return
	var direction := global_position.direction_to(target.global_position)
	if direction == Vector2.ZERO:
		return
	velocity = direction * pass_speed
	height = 0.0
	height_velocity = 0.0
	is_moving = true
	queue_redraw()

func kick(direction: Vector2, power: float, is_shot: bool = false) -> void:
	if direction.length_squared() < 0.0001:
		return
	var strength := clampf(power, 0.12, 1.0)
	velocity = direction.normalized() * (shot_speed if is_shot else pass_speed) * strength
	height = 0.0
	height_velocity = 210.0 * strength if is_shot else 45.0 * strength
	is_moving = true
	queue_redraw()

func stop() -> void:
	velocity = Vector2.ZERO
	height = 0.0
	height_velocity = 0.0
	is_moving = false
	queue_redraw()

func _physics_process(delta: float) -> void:
	if not is_moving:
		return
	global_position += velocity * delta
	velocity = velocity.move_toward(Vector2.ZERO, friction * delta)
	height_velocity -= gravity * delta
	height += height_velocity * delta
	if height < 0.0:
		height = 0.0
		height_velocity = absf(height_velocity) * 0.25
		if height_velocity < 24.0:
			height_velocity = 0.0
	if velocity.length() < 18.0 and height_velocity == 0.0:
		stop()
	queue_redraw()

func _draw() -> void:
	draw_circle(Vector2(2.0, 4.0), 9.0, Color(0.0, 0.0, 0.0, 0.25))
	draw_circle(Vector2(0.0, -height), 7.5, Color.WHITE)
	draw_arc(Vector2(0.0, -height), 5.5, 0.0, TAU, 18, Color("#252525"), 1.3, true)
