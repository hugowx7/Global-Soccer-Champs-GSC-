extends Node2D
class_name CampoControle

signal action_requested(action: Dictionary)

const FIELD_RECT := Rect2(Vector2(38, 42), Vector2(1204, 636))
const FIELD_CENTER := Vector2(640, 360)
const GOAL_CENTER := Vector2(1170, 360)

@onready var ball: BallPhysics = $Ball
@onready var goalkeeper: GoalkeeperAI = $Goalkeeper
@onready var swipe_input: SwipeMatchInput = $SwipeInput

var teammates: Array[Node2D] = []
var status_text := "Arraste para um companheiro para passar ou em direção ao gol para chutar."
var _shot_result_text := ""

func _ready() -> void:
	var positions := [
		Vector2(310, 220), Vector2(460, 510), Vector2(620, 210),
		Vector2(720, 500), Vector2(870, 350), Vector2(930, 230)
	]
	for i in range(positions.size()):
		var player := Node2D.new()
		player.name = "Teammate%d" % i
		player.position = positions[i]
		player.set_meta("player_id", i + 1)
		add_child(player)
		teammates.append(player)
	swipe_input.configure(ball, teammates, GOAL_CENTER, Vector2.RIGHT)
	swipe_input.action_requested.connect(_on_swipe_action)
	goalkeeper.goal_center = GOAL_CENTER
	goalkeeper.global_position = GOAL_CENTER
	queue_redraw()

func _on_swipe_action(action: Dictionary) -> void:
	var action_type := str(action.get("type", ""))
	if action_type == "pass":
		status_text = "Passe realizado. Faça outro arraste para continuar a jogada."
		queue_redraw()
		var target_value: Variant = action.get("receiver_position", ball.global_position)
		var target_position: Vector2 = target_value if target_value is Vector2 else ball.global_position
		await get_tree().create_timer(0.65).timeout
		ball.stop()
		ball.global_position = target_position
		swipe_input.set_input_enabled(true)
		queue_redraw()
	elif action_type == "shoot":
		status_text = "Finalização! O goleiro está reagindo..."
		var direction: Vector2 = action.get("direction", Vector2.RIGHT)
		var predicted_y := clampf(ball.global_position.y + direction.y * 140.0, 245.0, 475.0)
		goalkeeper.set_context(ball.global_position, GOAL_CENTER, predicted_y)
		queue_redraw()
	action_requested.emit(action)

func show_shot_result(goal: bool, description: String) -> void:
	_shot_result_text = "GOL!" if goal else "DEFESA / PARA FORA"
	status_text = description
	queue_redraw()

func get_status_text() -> String:
	return status_text

func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, Vector2(1280, 720)), Color("#0d171b"), true)
	draw_rect(FIELD_RECT, Color("#176b3d"), true)
	var line_color := Color(1.0, 1.0, 1.0, 0.86)
	draw_rect(FIELD_RECT, line_color, false, 4.0)
	draw_line(Vector2(640, 42), Vector2(640, 678), line_color, 3.0)
	draw_arc(FIELD_CENTER, 82.0, 0.0, TAU, 64, line_color, 3.0, true)
	draw_circle(FIELD_CENTER, 4.0, line_color)
	draw_rect(Rect2(Vector2(38, 215), Vector2(150, 290)), line_color, false, 3.0)
	draw_rect(Rect2(Vector2(1092, 215), Vector2(150, 290)), line_color, false, 3.0)
	draw_rect(Rect2(Vector2(38, 285), Vector2(55, 150)), line_color, false, 3.0)
	draw_rect(Rect2(Vector2(1187, 285), Vector2(55, 150)), line_color, false, 3.0)
	draw_string(ThemeDB.fallback_font, Vector2(50, 28), "CONTROLE MANUAL • ARRASTE PARA PASSAR OU CHUTAR", HORIZONTAL_ALIGNMENT_LEFT, -1, 17, Color.WHITE)
	for teammate in teammates:
		draw_circle(to_local(teammate.global_position), 13.0, Color("#dce8e2"))
		draw_arc(to_local(teammate.global_position), 13.0, 0.0, TAU, 20, Color("#263b32"), 2.0, true)
	draw_string(ThemeDB.fallback_font, Vector2(48, 710), status_text, HORIZONTAL_ALIGNMENT_LEFT, 1180, 18, Color.WHITE)
	if not _shot_result_text.is_empty():
		draw_string(ThemeDB.fallback_font, Vector2(545, 390), _shot_result_text, HORIZONTAL_ALIGNMENT_CENTER, 250, 30, Color("#ffe08a"))
