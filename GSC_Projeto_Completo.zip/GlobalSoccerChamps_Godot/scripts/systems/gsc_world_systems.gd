extends Node
class_name GSCWorldSystems

## Camada complementar do Global Soccer Champs.
## Mantém recursos, carreira de atleta, redes, crise financeira e academia
## em um save separado e versionado, para preservar o save do manager existente.

const SAVE_PATH := "user://gsc_world_state.json"
const SAVE_VERSION := 1

const FORMATIONS := [
	"4-4-2", "4-3-3", "4-2-3-1", "4-5-1", "3-5-2",
	"3-4-3", "3-2-4-1", "3-3-1-3", "5-3-2", "5-4-1",
	"4-1-4-1", "4-3-2-1", "4-1-2-1-2"
]

const CURRENCY_RATES := {"BRL": 5.00, "EUR": 0.92, "USD": 1.00}
const CURRENCY_SYMBOLS := {"BRL": "R$", "EUR": "€", "USD": "$"}

var state: Dictionary = {}
var _rng := RandomNumberGenerator.new()

func _ready() -> void:
	_rng.randomize()

func configure(club_id: int, club_name: String) -> void:
	if load_state():
		# Um único universo de save: trocar o clube não apaga a carreira de atleta,
		# histórico social, Bux ou progresso da academia.
		_normalize_state(club_id, club_name)
		save_state()
		return
	state = _new_state(club_id, club_name)
	save_state()

func _new_state(club_id: int, club_name: String) -> Dictionary:
	return {
		"version": SAVE_VERSION,
		"club_id": club_id,
		"club_name": club_name,
		"day": 1,
		"currency": "BRL",
		"bux": 25,
		"energy": 100,
		"medical_kits": 2,
		"club_finance": {
			"debt": 0,
			"weekly_wages": 0,
			"board_confidence": 70,
			"fan_trust": 65,
			"dressing_room": 70,
			"financial_stability": 75,
			"consecutive_losses": 0
		},
		"tactics": {"formation": "4-3-3", "mentality": "Equilibrada", "pressure": "Média"},
		"academy": {"level": 3, "facilities": 2, "scout_level": 1, "prospects": [], "promoted": []},
		"player_career": {},
		"social_feed": [
			{"day": 1, "source": "GSC News", "text": "A nova temporada está prestes a começar. A torcida espera boas notícias.", "kind": "news", "impact": 0}
		],
		"daily_reward_claimed": -1,
		"last_objective": "Treine seu elenco e prepare-se para a próxima partida.",
		"achievements": []
	}

func _normalize_state(club_id: int, club_name: String) -> void:
	state["version"] = SAVE_VERSION
	state["club_id"] = club_id
	state["club_name"] = club_name
	if not state.has("currency"): state["currency"] = "BRL"
	if not CURRENCY_RATES.has(str(state["currency"])): state["currency"] = "BRL"
	if not state.has("bux"): state["bux"] = 25
	if not state.has("energy"): state["energy"] = 100
	if not state.has("medical_kits"): state["medical_kits"] = 2
	if not state.has("club_finance"): state["club_finance"] = _new_state(club_id, club_name)["club_finance"]
	if not state.has("academy"): state["academy"] = _new_state(club_id, club_name)["academy"]
	if not state.has("social_feed"): state["social_feed"] = []
	if not state.has("player_career"): state["player_career"] = {}
	if not state.has("tactics"): state["tactics"] = {"formation": "4-3-3", "mentality": "Equilibrada", "pressure": "Média"}

func load_state() -> bool:
	if not FileAccess.file_exists(SAVE_PATH):
		return false
	var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if file == null:
		return false
	var parsed: Variant = JSON.parse_string(file.get_as_text())
	file.close()
	if not parsed is Dictionary:
		return false
	if int(parsed.get("version", 0)) > SAVE_VERSION:
		return false
	state = parsed
	return true

func save_state() -> bool:
	if state.is_empty():
		return false
	state["version"] = SAVE_VERSION
	var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if file == null:
		return false
	file.store_string(JSON.stringify(state))
	file.close()
	return true

func set_currency(code: String) -> bool:
	if not CURRENCY_RATES.has(code):
		return false
	state["currency"] = code
	save_state()
	return true

func format_money(base_usd: int) -> String:
	var code := str(state.get("currency", "BRL"))
	var value := int(round(float(base_usd) * float(CURRENCY_RATES.get(code, 5.0))))
	return "%s %s" % [str(CURRENCY_SYMBOLS.get(code, "R$")), _group_digits(value)]

func _group_digits(value: int) -> String:
	var digits := str(absi(value))
	var groups: Array[String] = []
	while digits.length() > 3:
		groups.push_front(digits.substr(digits.length() - 3, 3))
		digits = digits.substr(0, digits.length() - 3)
	groups.push_front(digits)
	var formatted := groups[0]
	for i in range(1, groups.size()):
		formatted += "." + groups[i]
	return formatted

func get_bux() -> int:
	return int(state.get("bux", 0))

func earn_bux(amount: int, reason: String) -> void:
	var reward := maxi(0, amount)
	state["bux"] = int(state.get("bux", 0)) + reward
	_add_social("GSC Central", "Você recebeu %d Bux: %s" % [reward, reason], "reward", 1)
	save_state()

func claim_daily_reward() -> Dictionary:
	var today := int(state.get("day", 1))
	if int(state.get("daily_reward_claimed", -1)) == today:
		return {"ok": false, "message": "O prêmio diário de hoje já foi resgatado."}
	state["daily_reward_claimed"] = today
	earn_bux(3, "objetivo diário concluído")
	return {"ok": true, "message": "Você ganhou 3 Bux grátis."}

func use_medical_kit() -> Dictionary:
	var kits := int(state.get("medical_kits", 0))
	if kits <= 0:
		return {"ok": false, "message": "Você não tem kits médicos disponíveis."}
	state["medical_kits"] = kits - 1
	state["energy"] = mini(100, int(state.get("energy", 100)) + 30)
	var athlete: Dictionary = state.get("player_career", {})
	var healed := int(athlete.get("injury_days", 0)) > 0
	if not athlete.is_empty():
		athlete["energy"] = mini(100, int(athlete.get("energy", 100)) + 30)
		if healed:
			athlete["injury_days"] = 0
			athlete["fitness"] = mini(100, int(athlete.get("fitness", 100)) + 20)
		state["player_career"] = athlete
	save_state()
	return {"ok": true, "message": "Kit médico utilizado. Energia recuperada e lesão tratada." if healed else "Kit médico utilizado. Energia recuperada em 30 pontos."}

func buy_medical_kit(balance: int) -> Dictionary:
	var price := 8000
	if balance < price:
		return {"ok": false, "message": "Saldo insuficiente para comprar um kit médico."}
	state["medical_kits"] = int(state.get("medical_kits", 0)) + 1
	save_state()
	return {"ok": true, "cost": price, "message": "Kit médico adquirido com dinheiro do clube."}

func advance_day() -> Dictionary:
	state["day"] = int(state.get("day", 1)) + 1
	state["energy"] = mini(100, int(state.get("energy", 100)) + 5)
	var athlete: Dictionary = state.get("player_career", {})
	if not athlete.is_empty() and int(athlete.get("injury_days", 0)) > 0:
		athlete["injury_days"] = maxi(0, int(athlete.get("injury_days", 0)) - 1)
		state["player_career"] = athlete
	var finance: Dictionary = state.get("club_finance", {})
	if int(state["day"]) % 7 == 0:
		var wages := int(finance.get("weekly_wages", 0))
		if wages > 0:
			finance["debt"] = int(finance.get("debt", 0)) + int(wages * 0.08)
			finance["financial_stability"] = maxi(0, int(finance.get("financial_stability", 75)) - 2)
			_add_social("GSC Finance", "A folha salarial da semana foi processada. Confira o fluxo de caixa.", "finance", -1)
	state["club_finance"] = finance
	if int(state["day"]) % 7 == 0:
		_add_social("Torcida GSC", "A torcida acompanha de perto os resultados e a situação do clube.", "fans", 0)
	save_state()
	return {"ok": true, "day": int(state["day"]), "energy": int(state["energy"])}

func update_club_context(balance: int, wage_limit: int, roster: Array = []) -> void:
	var finance: Dictionary = state.get("club_finance", {})
	var salary_total := 0
	for player in roster:
		salary_total += int(player.get("weekly_salary", 0))
	finance["weekly_wages"] = salary_total
	if balance < -10000:
		finance["financial_stability"] = maxi(0, int(finance.get("financial_stability", 75)) - 4)
		finance["debt"] = maxi(int(finance.get("debt", 0)), -balance)
	if int(finance.get("debt", 0)) > 0 and int(finance.get("financial_stability", 75)) < 35:
		_add_social("Imprensa", "A situação financeira virou assunto na coletiva. A diretoria cobra planejamento.", "crisis", -2)
	state["club_finance"] = finance
	save_state()

func repay_debt(balance: int, requested_amount: int) -> Dictionary:
	var finance: Dictionary = state.get("club_finance", {})
	var debt := int(finance.get("debt", 0))
	var amount := mini(debt, mini(balance, maxi(0, requested_amount)))
	if amount <= 0:
		return {"ok": false, "message": "Não há valor disponível para amortizar a dívida."}
	finance["debt"] = debt - amount
	finance["financial_stability"] = mini(100, int(finance.get("financial_stability", 75)) + 5)
	finance["board_confidence"] = mini(100, int(finance.get("board_confidence", 70)) + 2)
	state["club_finance"] = finance
	_add_social("Diretoria", "O clube amortizou %s da dívida. A estabilidade financeira melhorou." % format_money(amount), "finance", 2)
	save_state()
	return {"ok": true, "amount": amount, "remaining_debt": int(finance["debt"]), "message": "Dívida amortizada."}

func resolve_social_decision(choice: String) -> Dictionary:
	var finance: Dictionary = state.get("club_finance", {})
	match choice:
		"honest":
			finance["fan_trust"] = mini(100, int(finance.get("fan_trust", 65)) + 7)
			finance["board_confidence"] = mini(100, int(finance.get("board_confidence", 70)) + 2)
			_add_social("Rede GSC", "Sua entrevista transparente recebeu apoio de parte da torcida.", "social", 2)
		"promise":
			finance["board_confidence"] = mini(100, int(finance.get("board_confidence", 70)) + 6)
			finance["fan_trust"] = maxi(0, int(finance.get("fan_trust", 65)) - 3)
			_add_social("Rede GSC", "A promessa de resultados aumentou a pressão para a próxima partida.", "social", -1)
		"locker":
			finance["dressing_room"] = mini(100, int(finance.get("dressing_room", 70)) + 8)
			_add_social("Vestiário", "Uma conversa com o elenco melhorou o ambiente interno.", "team", 2)
		_:
			return {"ok": false, "message": "Escolha desconhecida."}
	state["club_finance"] = finance
	save_state()
	return {"ok": true, "message": "Decisão registrada."}

func _add_social(source: String, text: String, kind: String, impact: int) -> void:
	var feed: Array = state.get("social_feed", [])
	feed.push_front({"day": int(state.get("day", 1)), "source": source, "text": text, "kind": kind, "impact": impact})
	while feed.size() > 25:
		feed.pop_back()
	state["social_feed"] = feed

func get_social_feed() -> Array:
	return state.get("social_feed", []).duplicate(true)

func generate_academy_prospect() -> Dictionary:
	var academy: Dictionary = state.get("academy", {})
	var level := int(academy.get("level", 3))
	var scout_level := int(academy.get("scout_level", 1))
	var id_seed := int(state.get("day", 1)) * 1009 + int(state.get("club_id", 0)) * 17 + int(academy.get("prospects", []).size()) * 61
	_rng.seed = id_seed
	var age := _rng.randi_range(16, 18)
	var overall := clampi(30 + level * 2 + _rng.randi_range(-5, 10), 34, 75)
	var potential := clampi(overall + 8 + level + scout_level * 2 + _rng.randi_range(0, 16), overall, 94)
	var position := ["GK", "DEF", "MID", "ATT"][_rng.randi_range(0, 3)]
	var prospect := {
		"id": id_seed,
		"name": _generated_name(id_seed),
		"age": age,
		"position": position,
		"overall": overall,
		"potential": potential,
		"development": "Early Bloomer" if age <= 16 else "Late Developer",
		"source": "generated",
		"appearance": make_appearance(id_seed)
	}
	var prospects: Array = academy.get("prospects", [])
	prospects.push_back(prospect)
	academy["prospects"] = prospects
	state["academy"] = academy
	_add_social("Academia GSC", "Novo talento encontrado: %s (%s, GER %d)." % [prospect["name"], position, overall], "academy", 1)
	save_state()
	return prospect

func _generated_name(seed_value: int) -> String:
	var first := ["Lucas", "Mateus", "Caio", "Ravi", "Noah", "Enzo", "Theo", "Davi", "Ícaro", "Bruno"]
	var last := ["Almeida", "Costa", "Ferreira", "Silva", "Ramos", "Oliveira", "Santos", "Mendes", "Barbosa", "Nunes"]
	var first_index := int(posmod(seed_value, first.size()))
	var last_index := int(posmod(seed_value / 7, last.size()))
	return first[first_index] + " " + last[last_index]

func upgrade_academy(balance: int) -> Dictionary:
	var academy: Dictionary = state.get("academy", {})
	var level := int(academy.get("level", 3))
	if level >= 20:
		return {"ok": false, "message": "A academia já está no nível máximo."}
	var cost := 50000 * level
	if balance < cost:
		return {"ok": false, "message": "Saldo insuficiente para evoluir a academia."}
	academy["level"] = level + 1
	state["academy"] = academy
	_add_social("Academia GSC", "A academia subiu para o nível %d/20." % (level + 1), "academy", 2)
	save_state()
	return {"ok": true, "cost": cost, "level": level + 1}

func upgrade_facilities(balance: int) -> Dictionary:
	var academy: Dictionary = state.get("academy", {})
	var level := int(academy.get("facilities", 1))
	if level >= 20:
		return {"ok": false, "message": "Centro de treinamento no nível máximo."}
	var cost := 35000 * level
	if balance < cost:
		return {"ok": false, "message": "Saldo insuficiente para melhorar o centro de treinamento."}
	academy["facilities"] = level + 1
	state["academy"] = academy
	save_state()
	return {"ok": true, "cost": cost, "level": level + 1}

func upgrade_scout(balance: int) -> Dictionary:
	var academy: Dictionary = state.get("academy", {})
	var level := int(academy.get("scout_level", 1))
	if level >= 20:
		return {"ok": false, "message": "Rede de olheiros no nível máximo."}
	var cost := 25000 * level
	if balance < cost:
		return {"ok": false, "message": "Saldo insuficiente para contratar olheiros melhores."}
	academy["scout_level"] = level + 1
	state["academy"] = academy
	save_state()
	return {"ok": true, "cost": cost, "level": level + 1}

func promote_prospect(prospect_id: int) -> Dictionary:
	var academy: Dictionary = state.get("academy", {})
	var prospects: Array = academy.get("prospects", [])
	for i in range(prospects.size()):
		var prospect: Dictionary = prospects[i]
		if int(prospect.get("id", -1)) == prospect_id:
			academy.get("promoted", []).append(prospect)
			prospects.remove_at(i)
			academy["prospects"] = prospects
			state["academy"] = academy
			_add_social("Academia GSC", "%s foi promovido ao elenco principal." % str(prospect.get("name", "Jovem")), "academy", 1)
			save_state()
			return {"ok": true, "player": prospect}
	return {"ok": false, "message": "Talento não encontrado."}

func create_player_career(player_name: String, position: String, club_id: int, club_name: String) -> Dictionary:
	if not state.get("player_career", {}).is_empty():
		return {"ok": false, "message": "Você já possui uma carreira de atleta neste save."}
	var id_seed := int(Time.get_unix_time_from_system()) % 2147483000
	var athlete := {
		"id": id_seed,
		"name": player_name.strip_edges() if not player_name.strip_edges().is_empty() else "Novo Atleta",
		"position": position,
		"age": 17,
		"club_id": club_id,
		"club_name": club_name,
		"overall": 52,
		"potential": 88,
		"form": 50,
		"morale": 65,
		"fitness": 100,
		"energy": 100,
		"injury_days": 0,
		"xp": 0,
		"minutes": 0,
		"goals": 0,
		"assists": 0,
		"appearances": 0,
		"career_seasons": 0,
		"rival_name": _generated_name(id_seed + 991),
		"rival_score": 0,
		"contract_years": 3,
		"market_value": 50000,
		"appearance": make_appearance(id_seed)
	}
	state["player_career"] = athlete
	_add_social("GSC Esportes", "%s foi apresentado como nova promessa de %s." % [athlete["name"], club_name], "player", 2)
	save_state()
	return {"ok": true, "player": athlete}

func train_player_career(training: String) -> Dictionary:
	var athlete: Dictionary = state.get("player_career", {})
	if athlete.is_empty():
		return {"ok": false, "message": "Crie seu atleta primeiro."}
	if int(athlete.get("injury_days", 0)) > 0:
		return {"ok": false, "message": "Seu atleta está lesionado. Use um kit médico ou aguarde a recuperação."}
	if int(athlete.get("energy", 100)) < 15:
		return {"ok": false, "message": "Energia baixa. Descanse antes de treinar."}
	var xp_gain := 8
	match training:
		"Finalização": xp_gain = 9
		"Passe": xp_gain = 8
		"Velocidade": xp_gain = 7
		"Físico": xp_gain = 6
		_:
			training = "Técnico"
	athlete["xp"] = int(athlete.get("xp", 0)) + xp_gain
	athlete["energy"] = maxi(0, int(athlete.get("energy", 100)) - 15)
	if int(athlete["xp"]) >= 100 and int(athlete.get("overall", 52)) < int(athlete.get("potential", 88)):
		athlete["xp"] = int(athlete["xp"]) - 100
		athlete["overall"] = mini(int(athlete.get("potential", 88)), int(athlete.get("overall", 52)) + 1)
		_add_social("GSC Desenvolvimento", "%s evoluiu para GER %d após o treino." % [athlete["name"], athlete["overall"]], "player", 2)
	else:
		_add_social("Treino", "%s treinou %s e ganhou %d XP." % [athlete["name"], training.to_lower(), xp_gain], "player", 0)
	state["player_career"] = athlete
	save_state()
	return {"ok": true, "xp": xp_gain, "player": athlete}

func simulate_player_appearance() -> Dictionary:
	var athlete: Dictionary = state.get("player_career", {})
	if athlete.is_empty():
		return {"ok": false, "message": "Crie seu atleta primeiro."}
	if int(athlete.get("injury_days", 0)) > 0:
		return {"ok": false, "message": "Atleta lesionado. Trate a lesão ou avance os dias de recuperação."}
	athlete["appearances"] = int(athlete.get("appearances", 0)) + 1
	athlete["minutes"] = int(athlete.get("minutes", 0)) + _rng.randi_range(15, 90)
	athlete["energy"] = maxi(0, int(athlete.get("energy", 100)) - _rng.randi_range(12, 24))
	athlete["fitness"] = maxi(40, int(athlete.get("fitness", 100)) - _rng.randi_range(3, 10))
	if int(athlete["fitness"]) < 55 and _rng.randf() < 0.10:
		athlete["injury_days"] = _rng.randi_range(2, 5)
	var goals := 0
	var assists := 0
	if str(athlete.get("position", "ATA")) in ["ATA", "PE", "PD", "CA"]:
		goals = 1 if _rng.randf() < 0.23 else 0
		assists = 1 if _rng.randf() < 0.12 else 0
	else:
		goals = 1 if _rng.randf() < 0.08 else 0
		assists = 1 if _rng.randf() < 0.18 else 0
	athlete["goals"] = int(athlete.get("goals", 0)) + goals
	athlete["assists"] = int(athlete.get("assists", 0)) + assists
	athlete["rival_score"] = int(athlete.get("rival_score", 0)) + goals * 2 + assists
	athlete["form"] = clampi(int(athlete.get("form", 50)) + _rng.randi_range(-5, 8), 1, 99)
	athlete["morale"] = clampi(int(athlete.get("morale", 65)) + (5 if goals + assists > 0 else -1), 1, 100)
	athlete["market_value"] = int(pow(float(athlete.get("overall", 52)), 2.25) * 1500.0 * (1.0 + float(athlete.get("form", 50)) / 200.0))
	state["player_career"] = athlete
	var performance := "marcou %d gol(s) e deu %d assistência(s)" % [goals, assists]
	_add_social("GSC Pós-jogo", "%s %s na partida. Rivalidade com %s: %d ponto(s) acumulados. GER dinâmico: %d." % [
		athlete["name"], performance, str(athlete.get("rival_name", "Rival")), int(athlete.get("rival_score", 0)), get_dynamic_overall()
	], "match", 2 if goals + assists > 0 else 0)
	save_state()
	return {"ok": true, "goals": goals, "assists": assists, "player": athlete}

func get_dynamic_overall() -> int:
	var athlete: Dictionary = state.get("player_career", {})
	if athlete.is_empty():
		return 0
	var base := int(athlete.get("overall", 50))
	var form_bonus := int((int(athlete.get("form", 50)) - 50) / 20)
	var morale_bonus := int((int(athlete.get("morale", 65)) - 60) / 25)
	var fitness_bonus := int((int(athlete.get("fitness", 100)) - 70) / 30)
	return clampi(base + form_bonus + morale_bonus + fitness_bonus, 1, 99)

func make_appearance(seed_value: int) -> Dictionary:
	var local_rng := RandomNumberGenerator.new()
	local_rng.seed = maxi(1, seed_value)
	var skin := ["#f5d0ad", "#d9a47f", "#b97752", "#8d563b", "#633a2b", "#edc19a"]
	var hair := ["#1c1715", "#3a241b", "#765034", "#c9a35b", "#d9d9d9", "#a83d2f"]
	var hairstyles := ["curto", "degradê", "cacheado", "crespo", "médio", "raspado"]
	var beards := ["nenhuma", "barba curta", "cavanhaque", "barba cheia", "bigode"]
	var shirt_colors := ["#1769aa", "#e8e8e8", "#c82d3b", "#f2c84b", "#222b38", "#16845b"]
	return {
		"skin": skin[local_rng.randi_range(0, skin.size() - 1)],
		"hair": hair[local_rng.randi_range(0, hair.size() - 1)],
		"hairstyle": hairstyles[local_rng.randi_range(0, hairstyles.size() - 1)],
		"beard": beards[local_rng.randi_range(0, beards.size() - 1)],
		"shirt": shirt_colors[local_rng.randi_range(0, shirt_colors.size() - 1)],
		"eyes": "#2b211d"
	}

func set_tactics(formation: String, mentality: String, pressure: String) -> void:
	if not FORMATIONS.has(formation): formation = "4-3-3"
	state["tactics"] = {"formation": formation, "mentality": mentality, "pressure": pressure}
	save_state()

func sector_averages(players: Array) -> Dictionary:
	var sums := {"DEF": 0.0, "MID": 0.0, "ATT": 0.0}
	var counts := {"DEF": 0, "MID": 0, "ATT": 0}
	for p in players:
		var role := str(p.get("position", "MID"))
		var bucket := "MID"
		if role in ["GK", "DEF", "LB", "RB", "CB"]: bucket = "DEF"
		elif role in ["ATT", "ST", "CF", "LW", "RW", "CA", "ATA"]: bucket = "ATT"
		sums[bucket] += float(p.get("overall", 50))
		counts[bucket] += 1
	return {
		"defence": int(sums["DEF"] / max(1, counts["DEF"])),
		"midfield": int(sums["MID"] / max(1, counts["MID"])),
		"attack": int(sums["ATT"] / max(1, counts["ATT"]))
	}

func get_crisis_label() -> String:
	var f: Dictionary = state.get("club_finance", {})
	var debt := int(f.get("debt", 0))
	var stability := int(f.get("financial_stability", 75))
	if debt > 1000000 or stability < 20: return "CRISE FINANCEIRA GRAVE"
	if debt > 0 or stability < 45: return "ATENÇÃO FINANCEIRA"
	if int(f.get("board_confidence", 70)) < 25: return "DIRETORIA SOB PRESSÃO"
	return "CLUBE ESTÁVEL"

func take_emergency_loan(amount: int = 250000) -> int:
	var loan_amount := maxi(0, amount)
	var finance: Dictionary = state.get("club_finance", {})
	var debt := int(finance.get("debt", 0))
	finance["debt"] = debt + int(loan_amount * 1.08)
	finance["financial_stability"] = maxi(0, int(finance.get("financial_stability", 75)) - 8)
	state["club_finance"] = finance
	_add_social("GSC Finance", "A diretoria contratou um empréstimo emergencial de %s, com juros fixos de 8%%." % format_money(loan_amount), "finance", -2)
	save_state()
	return loan_amount

func spend_bux(amount: int) -> bool:
	var cost := maxi(0, amount)
	var current := int(state.get("bux", 0))
	if current < cost:
		return false
	state["bux"] = current - cost
	save_state()
	return true


func apply_tactical_modifiers(team_snapshot: Dictionary, players: Array) -> Dictionary:
	var result := team_snapshot.duplicate(true)
	var averages := sector_averages(players)
	var formation := str(state.get("tactics", {}).get("formation", "4-3-3"))
	var mentality := str(state.get("tactics", {}).get("mentality", "Equilibrada"))
	var pressure := str(state.get("tactics", {}).get("pressure", "Média"))
	var defence_bonus := 0.0
	var midfield_bonus := 0.0
	var attack_bonus := 0.0
	if formation.begins_with("5-") or formation == "3-5-2":
		defence_bonus += 2.0
	if formation in ["4-3-3", "3-4-3", "3-3-1-3"]:
		attack_bonus += 2.0
	if formation in ["4-2-3-1", "4-1-4-1", "4-3-2-1", "4-5-1"]:
		midfield_bonus += 2.0
	if mentality == "Ofensiva":
		attack_bonus += 3.0
		defence_bonus -= 2.0
	elif mentality == "Defensiva":
		defence_bonus += 3.0
		attack_bonus -= 2.0
	if pressure == "Alta":
		midfield_bonus += 1.0
		attack_bonus += 1.0
		defence_bonus -= 1.0
	elif pressure == "Baixa":
		defence_bonus += 1.0
		attack_bonus -= 1.0
	result["defence"] = clampf(float(averages["defence"]) + defence_bonus, 1.0, 99.0)
	result["midfield"] = clampf(float(averages["midfield"]) + midfield_bonus, 1.0, 99.0)
	result["attack"] = clampf(float(averages["attack"]) + attack_bonus, 1.0, 99.0)
	result["tactical_formation"] = formation
	result["tactical_mentality"] = mentality
	result["tactical_pressure"] = pressure
	return result
