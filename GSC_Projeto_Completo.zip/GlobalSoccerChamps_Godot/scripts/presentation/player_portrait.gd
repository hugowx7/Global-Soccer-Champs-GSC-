extends Control
class_name GSCPlayerPortrait

## Retrato original gerado proceduralmente para cada atleta.
## Varia cor de pele, cabelo, penteado, barba e uniforme usando uma seed estável.

var player_data: Dictionary = {}
var appearance: Dictionary = {}

func set_player_data(data: Dictionary) -> void:
	player_data = data.duplicate(true)
	appearance = player_data.get("appearance", {})
	queue_redraw()

func _ready() -> void:
	custom_minimum_size = Vector2(96, 108)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	queue_redraw()

func _draw() -> void:
	var w := size.x
	var h := size.y
	if w <= 0.0 or h <= 0.0:
		return
	var skin := _color("skin", "#d9a47f")
	var hair := _color("hair", "#2b211d")
	var shirt := _color("shirt", "#1769aa")
	var eyes := _color("eyes", "#2b211d")
	draw_rect(Rect2(Vector2.ZERO, size), Color("#263849"), true)
	draw_rect(Rect2(Vector2(2, 2), size - Vector2(4, 4)), Color("#32495b"), false, 2.0)
	# Ombros e camisa.
	var shoulders := PackedVector2Array([
		Vector2(w * 0.08, h * 0.98), Vector2(w * 0.18, h * 0.76),
		Vector2(w * 0.37, h * 0.68), Vector2(w * 0.63, h * 0.68),
		Vector2(w * 0.82, h * 0.76), Vector2(w * 0.92, h * 0.98)
	])
	draw_colored_polygon(shoulders, shirt)
	# Pescoço.
	draw_rect(Rect2(w * 0.42, h * 0.61, w * 0.16, h * 0.18), skin, true)
	# Orelhas e rosto.
	draw_circle(Vector2(w * 0.28, h * 0.40), w * 0.075, skin)
	draw_circle(Vector2(w * 0.72, h * 0.40), w * 0.075, skin)
	draw_circle(Vector2(w * 0.50, h * 0.40), minf(w, h) * 0.245, skin)
	# Cabelo com variações de estilo.
	var style := str(appearance.get("hairstyle", "curto"))
	if style == "raspado":
		draw_arc(Vector2(w * 0.50, h * 0.40), minf(w, h) * 0.247, PI, TAU, 32, hair, 5.0, true)
	elif style == "cacheado" or style == "crespo":
		for i in range(11):
			var x := w * (0.28 + float(i) * 0.044)
			var y := h * (0.205 + float(abs(i - 5)) * 0.004)
			draw_circle(Vector2(x, y), w * (0.045 if style == "crespo" else 0.052), hair)
		draw_rect(Rect2(w * 0.27, h * 0.23, w * 0.46, h * 0.09), hair, true)
	elif style == "médio":
		draw_colored_polygon(PackedVector2Array([
			Vector2(w * 0.25, h * 0.42), Vector2(w * 0.24, h * 0.23),
			Vector2(w * 0.35, h * 0.14), Vector2(w * 0.64, h * 0.14),
			Vector2(w * 0.76, h * 0.25), Vector2(w * 0.75, h * 0.48),
			Vector2(w * 0.68, h * 0.35), Vector2(w * 0.33, h * 0.35)
		]), hair)
	else:
		draw_colored_polygon(PackedVector2Array([
			Vector2(w * 0.26, h * 0.43), Vector2(w * 0.27, h * 0.22),
			Vector2(w * 0.38, h * 0.15), Vector2(w * 0.65, h * 0.16),
			Vector2(w * 0.74, h * 0.27), Vector2(w * 0.71, h * 0.39),
			Vector2(w * 0.66, h * 0.31), Vector2(w * 0.35, h * 0.31)
		]), hair)
	# Sobrancelhas, olhos, nariz e boca.
	draw_line(Vector2(w * 0.36, h * 0.37), Vector2(w * 0.45, h * 0.36), hair.darkened(0.1), 2.0)
	draw_line(Vector2(w * 0.55, h * 0.36), Vector2(w * 0.64, h * 0.37), hair.darkened(0.1), 2.0)
	draw_circle(Vector2(w * 0.405, h * 0.405), w * 0.018, eyes)
	draw_circle(Vector2(w * 0.595, h * 0.405), w * 0.018, eyes)
	draw_line(Vector2(w * 0.50, h * 0.42), Vector2(w * 0.48, h * 0.49), skin.darkened(0.22), 1.8)
	draw_line(Vector2(w * 0.43, h * 0.54), Vector2(w * 0.57, h * 0.54), Color("#7b3e3a"), 2.0)
	# Barba e bigode opcionais.
	var beard := str(appearance.get("beard", "nenhuma"))
	if beard != "nenhuma":
		draw_line(Vector2(w * 0.38, h * 0.56), Vector2(w * 0.62, h * 0.56), hair, 3.0)
		if beard == "barba cheia":
			draw_colored_polygon(PackedVector2Array([
				Vector2(w * 0.34, h * 0.52), Vector2(w * 0.39, h * 0.62),
				Vector2(w * 0.50, h * 0.68), Vector2(w * 0.61, h * 0.62),
				Vector2(w * 0.66, h * 0.52), Vector2(w * 0.59, h * 0.58),
				Vector2(w * 0.41, h * 0.58)
			]), hair)
		elif beard == "cavanhaque":
			draw_colored_polygon(PackedVector2Array([
				Vector2(w * 0.44, h * 0.56), Vector2(w * 0.56, h * 0.56),
				Vector2(w * 0.54, h * 0.64), Vector2(w * 0.50, h * 0.66),
				Vector2(w * 0.46, h * 0.64)
			]), hair)
	# Detalhe de gola.
	draw_arc(Vector2(w * 0.50, h * 0.76), w * 0.12, 0.0, PI, 18, Color("#dfe8e4"), 2.0, true)

func _color(key: String, fallback: String) -> Color:
	var raw := str(appearance.get(key, fallback))
	return Color(raw) if raw.begins_with("#") else Color(fallback)
