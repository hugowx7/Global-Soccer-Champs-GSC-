extends Node
class_name GSCCustomTournamentManager

## Criador offline de torneios customizados do GSC.
const SAVE_PATH := "user://gsc_custom_tournaments.json"
var tournaments: Array = []

func _ready() -> void:
	load_tournaments()

func load_tournaments() -> void:
	if not FileAccess.file_exists(SAVE_PATH):
		return
	var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if file == null:
		return
	var parsed: Variant = JSON.parse_string(file.get_as_text())
	file.close()
	if parsed is Array:
		tournaments = parsed

func save_tournaments() -> bool:
	var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if file == null:
		return false
	file.store_string(JSON.stringify(tournaments))
	file.close()
	return true

func create_league(name: String, clubs: Array) -> Dictionary:
	var ids := _unique_club_ids(clubs)
	if ids.size() < 8 or ids.size() > 32:
		return {"ok": false, "message": "A liga personalizada precisa ter de 8 a 32 clubes."}
	var rotation := ids.duplicate()
	if rotation.size() % 2 == 1:
		rotation.append(-1)
	var first_leg: Array = []
	var size := rotation.size()
	for round_index in range(size - 1):
		for match_index in range(int(size / 2)):
			var home_id := int(rotation[match_index])
			var away_id := int(rotation[size - 1 - match_index])
			if home_id < 0 or away_id < 0:
				continue
			if (round_index + match_index) % 2 == 1:
				var swap := home_id
				home_id = away_id
				away_id = swap
			first_leg.append({
				"round": round_index + 1,
				"home_club_id": home_id,
				"away_club_id": away_id,
				"played": false,
				"home_goals": -1,
				"away_goals": -1
			})
		var last_id := int(rotation.pop_back())
		rotation.insert(1, last_id)
	var fixtures: Array = []
	for match in first_leg:
		var first := match.duplicate(true)
		first["id"] = fixtures.size() + 1
		fixtures.append(first)
	for match in first_leg:
		var second := match.duplicate(true)
		second["id"] = fixtures.size() + 1
		second["round"] = int(match["round"]) + size - 1
		second["home_club_id"] = int(match["away_club_id"])
		second["away_club_id"] = int(match["home_club_id"])
		fixtures.append(second)
	return _store_tournament(name, "Liga", ids, fixtures, [])

func create_cup(name: String, clubs: Array) -> Dictionary:
	var ids := _unique_club_ids(clubs)
	if ids.size() < 4 or ids.size() > 16:
		return {"ok": false, "message": "A copa personalizada precisa ter de 4 a 16 clubes."}
	var bracket_size := 1
	while bracket_size < ids.size():
		bracket_size *= 2
	var slots: Array = ids.duplicate()
	while slots.size() < bracket_size:
		slots.append(-1)
	var first_round: Array = []
	var byes: Array = []
	for i in range(0, slots.size(), 2):
		var home_id := int(slots[i])
		var away_id := int(slots[i + 1])
		if home_id < 0:
			byes.append(away_id)
		elif away_id < 0:
			byes.append(home_id)
		else:
			first_round.append({
				"home_club_id": home_id,
				"away_club_id": away_id,
				"played": false,
				"home_goals": -1,
				"away_goals": -1
			})
	return _store_tournament(name, "Copa", ids, first_round, byes)

func _unique_club_ids(clubs: Array) -> Array:
	var result: Array = []
	for club in clubs:
		var id := int(club)
		if id > 0 and not result.has(id):
			result.append(id)
	return result

func _store_tournament(name: String, format: String, ids: Array, fixtures: Array, byes: Array) -> Dictionary:
	var tournament := {
		"id": int(Time.get_unix_time_from_system()),
		"name": name.strip_edges() if not name.strip_edges().is_empty() else "Torneio GSC",
		"format": format,
		"club_ids": ids,
		"club_count": ids.size(),
		"fixtures": fixtures,
		"byes": byes,
		"created_at": Time.get_datetime_string_from_system()
	}
	tournaments.push_front(tournament)
	save_tournaments()
	return {"ok": true, "tournament": tournament, "message": "%s criado com %d clubes." % [format, ids.size()]}

func get_tournaments() -> Array:
	return tournaments.duplicate(true)
