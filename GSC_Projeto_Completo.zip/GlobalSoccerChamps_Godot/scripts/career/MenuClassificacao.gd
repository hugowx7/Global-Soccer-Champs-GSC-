extends Control
class_name MenuClassificacao

var career_manager: CareerManager
var list_container: VBoxContainer
var title_label: Label

func _ready() -> void:
	_build_interface()
	refresh()

func set_career_manager(manager: CareerManager) -> void:
	career_manager = manager
	refresh()

func _build_interface() -> void:
	var background := ColorRect.new()
	background.color = Color("#101a20")
	background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(background)
	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.add_theme_constant_override("margin_left", 22)
	margin.add_theme_constant_override("margin_right", 22)
	margin.add_theme_constant_override("margin_top", 18)
	margin.add_theme_constant_override("margin_bottom", 18)
	add_child(margin)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 12)
	margin.add_child(column)
	title_label = Label.new()
	title_label.text = "CLASSIFICAÇÃO"
	title_label.add_theme_font_size_override("font_size", 30)
	title_label.add_theme_color_override("font_color", Color("#f1f7f3"))
	column.add_child(title_label)
	var header := HBoxContainer.new()
	for heading in ["POS", "CLUBE", "J", "V", "E", "D", "SG", "PTS"]:
		var label := Label.new()
		label.text = heading
		label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		label.size_flags_horizontal = Control.SIZE_EXPAND_FILL if heading == "CLUBE" else Control.SIZE_SHRINK_CENTER
		label.custom_minimum_size.x = 48 if heading != "CLUBE" else 250
		label.add_theme_color_override("font_color", Color("#a8c8b4"))
		header.add_child(label)
	column.add_child(header)
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	column.add_child(scroll)
	list_container = VBoxContainer.new()
	list_container.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list_container.add_theme_constant_override("separation", 5)
	scroll.add_child(list_container)
	var back := Button.new()
	back.text = "Voltar"
	back.custom_minimum_size.y = 48
	back.pressed.connect(func() -> void: queue_free())
	column.add_child(back)

func refresh() -> void:
	if not is_inside_tree() or list_container == null:
		return
	for child in list_container.get_children():
		child.queue_free()
	if career_manager == null or not career_manager.has_career():
		var empty := Label.new()
		empty.text = "Inicie uma carreira para ver a classificação."
		list_container.add_child(empty)
		return
	title_label.text = "DIVISÃO %02d • TEMPORADA %d" % [int(career_manager.career.get("league_id", 1)), career_manager.get_season()]
	var standings := career_manager.get_standings()
	var user_club_id := career_manager.get_current_club_id()
	for i in range(standings.size()):
		var row: Dictionary = standings[i]
		var club_id := int(row.get("club_id", 0))
		var is_user := club_id == user_club_id
		var hbox := HBoxContainer.new()
		hbox.custom_minimum_size.y = 36
		var fields := [
			str(i + 1),
			str(row.get("club_name", "Clube")),
			str(row.get("played", 0)),
			str(row.get("wins", 0)),
			str(row.get("draws", 0)),
			str(row.get("losses", 0)),
			str(int(row.get("goals_for", 0)) - int(row.get("goals_against", 0))),
			str(row.get("points", 0))
		]
		for field_index in range(fields.size()):
			if field_index == 1:
				var club_cell := HBoxContainer.new()
				club_cell.size_flags_horizontal = Control.SIZE_EXPAND_FILL
				club_cell.add_theme_constant_override("separation", 8)
				var shield := TextureRect.new()
				shield.custom_minimum_size = Vector2(28, 28)
				shield.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
				if career_manager.database != null:
					shield.texture = career_manager.database.get_logo_texture(club_id)
				club_cell.add_child(shield)
				var club_label := Label.new()
				club_label.text = fields[field_index]
				club_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
				club_label.add_theme_color_override("font_color", Color("#ffe08a") if is_user else Color("#edf3ef"))
				club_cell.add_child(club_label)
				hbox.add_child(club_cell)
			else:
				var label := Label.new()
				label.text = fields[field_index]
				label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
				label.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
				label.custom_minimum_size.x = 48
				label.add_theme_color_override("font_color", Color("#ffe08a") if is_user else Color("#edf3ef"))
				if is_user:
					label.add_theme_font_size_override("font_size", 15)
				hbox.add_child(label)
		list_container.add_child(hbox)
		var separator := HSeparator.new()
		list_container.add_child(separator)
