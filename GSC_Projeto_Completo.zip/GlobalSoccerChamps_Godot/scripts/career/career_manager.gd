extends Node
class_name CareerManager

## Gerencia carreira, calendário, classificação, mercado, evolução e finanças.
## Os campeonatos são divisões sintéticas: o Data Pack original não informa
## a competição real de cada clube nem o elenco verdadeiro de cada jogador.

signal career_updated
signal finance_updated(new_balance: int)

const SAVE_PATH := "user://manager_career_save.json"
const SEASON_START := 2026

var database: GeradorBancoDados
var career: Dictionary = {}
var _rng := RandomNumberGenerator.new()

func _ready() -> void:
	_rng.randomize()

func configure(database_node: GeradorBancoDados) -> void:
	database = database_node

func start_career(club_id: int) -> Dictionary:
	if database == null:
		return {"ok": false, "error": "Banco de dados ainda não foi configurado."}
	var club := database.get_club(club_id)
	if club.is_empty():
		return {"ok": false, "error": "Clube não encontrado."}

	var league_id := int(club.get("league_id", 1))
	var league_clubs := database.get_clubs_for_league(league_id)
	if league_clubs.size() < 2:
		return {"ok": false, "error": "Não há clubes suficientes nesta divisão."}

	var standings: Dictionary = {}
	for team in league_clubs:
		var team_id := int(team["id"])
		standings[str(team_id)] = {
			"club_id": team_id,
			"club_name": str(team["name"]),
			"played": 0,
			"wins": 0,
			"draws": 0,
			"losses": 0,
			"goals_for": 0,
			"goals_against": 0,
			"points": 0
		}

	var fixtures := _create_fixtures(league_clubs, league_id)
	career = {
		"career_name": "Carreira - " + str(club.get("name", "Clube")),
		"club_id": club_id,
		"club_name": str(club.get("name", "Clube")),
		"league_id": league_id,
		"season": SEASON_START,
		"current_round": 1,
		"club_balance": int(club.get("balance", club.get("budget", 500000))),
		"wage_limit": int(club.get("wage_limit", 50000)),
		"fixtures": fixtures,
		"standings": standings,
		"history": [],
		"last_result": "Ainda não disputou partidas."
	}
	save_career()
	career_updated.emit()
	return {"ok": true, "club": club, "teams": league_clubs.size(), "fixtures": fixtures.size()}

func _create_fixtures(league_clubs: Array, league_id: int) -> Array:
	var team_ids: Array[int] = []
	for team in league_clubs:
		team_ids.append(int(team["id"]))
	if team_ids.size() % 2 == 1:
		team_ids.append(-1)

	var first_leg: Array = []
	var count := team_ids.size()
	for round_index in range(count - 1):
		for match_index in range(int(count / 2)):
			var first_id := int(team_ids[match_index])
			var second_id := int(team_ids[count - 1 - match_index])
			if first_id == -1 or second_id == -1:
				continue
			var home_id := first_id
			var away_id := second_id
			if (round_index + match_index) % 2 == 1:
				home_id = second_id
				away_id = first_id
			first_leg.append({
				"id": first_leg.size() + 1,
				"league_id": league_id,
				"round": round_index + 1,
				"home_club_id": home_id,
				"away_club_id": away_id,
				"home_goals": -1,
				"away_goals": -1,
				"played": false
			})
		var last_id := int(team_ids.pop_back())
		team_ids.insert(1, last_id)

	var fixtures: Array = []
	for fixture in first_leg:
		fixtures.append(fixture)
	for fixture in first_leg:
		var reverse_fixture: Dictionary = fixture.duplicate(true)
		reverse_fixture["id"] = fixtures.size() + 1
		reverse_fixture["round"] = int(fixture["round"]) + count - 1
		var old_home := int(fixture["home_club_id"])
		reverse_fixture["home_club_id"] = int(fixture["away_club_id"])
		reverse_fixture["away_club_id"] = old_home
		fixtures.append(reverse_fixture)
	return fixtures

func has_career() -> bool:
	return not career.is_empty() and int(career.get("club_id", 0)) > 0

func get_current_club_id() -> int:
	return int(career.get("club_id", 0))

func get_current_club_name() -> String:
	return str(career.get("club_name", ""))

func get_current_round() -> int:
	return int(career.get("current_round", 1))

func get_season() -> int:
	return int(career.get("season", SEASON_START))

func get_balance() -> int:
	return int(career.get("club_balance", 0))

func get_next_fixture() -> Dictionary:
	if not has_career():
		return {}
	var fixtures: Array = career.get("fixtures", [])
	for fixture_variant in fixtures:
		var fixture: Dictionary = fixture_variant
		if int(fixture.get("round", 0)) == get_current_round() and not bool(fixture.get("played", false)):
			if int(fixture["home_club_id"]) == get_current_club_id() or int(fixture["away_club_id"]) == get_current_club_id():
				return fixture.duplicate(true)
	# Caso o usuário já tenha jogado a partida da rodada, procura a próxima rodada.
	for fixture_variant in fixtures:
		var fixture_next: Dictionary = fixture_variant
		if not bool(fixture_next.get("played", false)) and (int(fixture_next["home_club_id"]) == get_current_club_id() or int(fixture_next["away_club_id"]) == get_current_club_id()):
			career["current_round"] = int(fixture_next["round"])
			return fixture_next.duplicate(true)
	return {}

func get_club_name(club_id: int) -> String:
	var club := database.get_club(club_id) if database != null else {}
	return str(club.get("name", "Clube " + str(club_id)))

func make_team_snapshot(club_id: int) -> Dictionary:
	var club := database.get_club(club_id)
	var roster := database.get_roster(club_id)
	var totals := {"GK": 0.0, "DEF": 0.0, "MID": 0.0, "ATT": 0.0}
	var counts := {"GK": 0, "DEF": 0, "MID": 0, "ATT": 0}
	for player in roster:
		var role := str(player.get("position", "MID"))
		if totals.has(role):
			totals[role] = float(totals[role]) + float(player.get("overall", 50))
			counts[role] = int(counts[role]) + 1
	var goalkeeper := _average_role(totals, counts, "GK", 55.0)
	var defence := _average_role(totals, counts, "DEF", 52.0)
	var midfield := _average_role(totals, counts, "MID", 52.0)
	var attack := _average_role(totals, counts, "ATT", 52.0)
	return {
		"id": club_id,
		"name": str(club.get("name", "Clube")),
		"attack": attack,
		"midfield": midfield,
		"defence": defence,
		"goalkeeper": goalkeeper,
		"reputation": int(club.get("reputation", 50))
	}

func _average_role(totals: Dictionary, counts: Dictionary, role: String, fallback: float) -> float:
	var count := int(counts.get(role, 0))
	if count <= 0:
		return fallback
	return float(totals[role]) / float(count)

func get_standings() -> Array:
	var result: Array = []
	for row_variant in career.get("standings", {}).values():
		var standing_row: Dictionary = row_variant
		result.append(standing_row.duplicate(true))
	result.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
		if int(a["points"]) != int(b["points"]):
			return int(a["points"]) > int(b["points"])
		var gd_a := int(a["goals_for"]) - int(a["goals_against"])
		var gd_b := int(b["goals_for"]) - int(b["goals_against"])
		if gd_a != gd_b:
			return gd_a > gd_b
		if int(a["wins"]) != int(b["wins"]):
			return int(a["wins"]) > int(b["wins"])
		return str(a["club_name"]) < str(b["club_name"])
	)
	return result

func register_match_result(fixture_id: int, match_state: Dictionary) -> Dictionary:
	if not has_career():
		return {"ok": false, "error": "Nenhuma carreira ativa."}
	var fixtures: Array = career.get("fixtures", [])
	var found := false
	var fixture_result: Dictionary = {}
	for i in range(fixtures.size()):
		var fixture: Dictionary = fixtures[i]
		if int(fixture.get("id", -1)) == fixture_id and not bool(fixture.get("played", false)):
			fixture["home_goals"] = int(match_state.get("home_goals", 0))
			fixture["away_goals"] = int(match_state.get("away_goals", 0))
			fixture["played"] = true
			fixtures[i] = fixture
			fixture_result = fixture
			found = true
			break
	if not found:
		return {"ok": false, "error": "Partida não encontrada ou já finalizada."}

	var home_id := int(fixture_result["home_club_id"])
	var away_id := int(fixture_result["away_club_id"])
	var home_goals := int(fixture_result["home_goals"])
	var away_goals := int(fixture_result["away_goals"])
	_update_standing(home_id, away_id, home_goals, away_goals)
	# Simula automaticamente os demais jogos da rodada para a tabela não ficar
	# limitada apenas às partidas disputadas pelo clube controlado pelo usuário.
	var completed_round := int(fixture_result["round"])
	for fixture_index in range(fixtures.size()):
		var other_fixture: Dictionary = fixtures[fixture_index]
		if int(other_fixture.get("round", 0)) != completed_round or bool(other_fixture.get("played", false)):
			continue
		var ai_home_goals := _rng.randi_range(0, 3)
		var ai_away_goals := _rng.randi_range(0, 3)
		other_fixture["home_goals"] = ai_home_goals
		other_fixture["away_goals"] = ai_away_goals
		other_fixture["played"] = true
		fixtures[fixture_index] = other_fixture
		_update_standing(int(other_fixture["home_club_id"]), int(other_fixture["away_club_id"]), ai_home_goals, ai_away_goals)
	career["fixtures"] = fixtures
	career["last_result"] = "%s %d x %d %s" % [get_club_name(home_id), home_goals, away_goals, get_club_name(away_id)]
	career["history"].append({
		"season": get_season(),
		"round": int(fixture_result["round"]),
		"home": get_club_name(home_id),
		"away": get_club_name(away_id),
		"home_goals": home_goals,
		"away_goals": away_goals
	})
	_process_match_finances(home_id, away_id, home_goals, away_goals)
	var all_round_finished := true
	for item_variant in fixtures:
		var item: Dictionary = item_variant
		if int(item["round"]) == int(fixture_result["round"]) and not bool(item["played"]):
			all_round_finished = false
			break
	if all_round_finished:
		career["current_round"] = int(fixture_result["round"]) + 1
		if int(career["current_round"]) > _round_count(fixtures):
			_finish_season()
	save_career()
	career_updated.emit()
	return {"ok": true, "result": str(career["last_result"]), "balance": get_balance()}

func _update_standing(home_id: int, away_id: int, home_goals: int, away_goals: int) -> void:
	var standings: Dictionary = career.get("standings", {})
	var home: Dictionary = standings.get(str(home_id), {})
	var away: Dictionary = standings.get(str(away_id), {})
	if home.is_empty() or away.is_empty():
		return
	home["played"] = int(home["played"]) + 1
	away["played"] = int(away["played"]) + 1
	home["goals_for"] = int(home["goals_for"]) + home_goals
	home["goals_against"] = int(home["goals_against"]) + away_goals
	away["goals_for"] = int(away["goals_for"]) + away_goals
	away["goals_against"] = int(away["goals_against"]) + home_goals
	if home_goals > away_goals:
		home["wins"] = int(home["wins"]) + 1
		home["points"] = int(home["points"]) + 3
		away["losses"] = int(away["losses"]) + 1
	elif away_goals > home_goals:
		away["wins"] = int(away["wins"]) + 1
		away["points"] = int(away["points"]) + 3
		home["losses"] = int(home["losses"]) + 1
	else:
		home["draws"] = int(home["draws"]) + 1
		away["draws"] = int(away["draws"]) + 1
		home["points"] = int(home["points"]) + 1
		away["points"] = int(away["points"]) + 1
	standings[str(home_id)] = home
	standings[str(away_id)] = away
	career["standings"] = standings

func _process_match_finances(home_id: int, away_id: int, home_goals: int, away_goals: int) -> void:
	var balance := get_balance()
	var gate_income := 300000 + int(_rng.randi_range(0, 300000))
	var result_bonus := 60000 if (home_id == get_current_club_id() and home_goals > away_goals) or (away_id == get_current_club_id() and away_goals > home_goals) else 30000
	var roster := database.get_roster(get_current_club_id())
	var weekly_wages := 0
	for player in roster:
		weekly_wages += int(player.get("weekly_salary", 0))
	var wages_paid := int(weekly_wages * 1.0)
	balance += gate_income + result_bonus - wages_paid
	career["club_balance"] = maxi(0, balance)
	career["last_finance"] = {
		"gate_income": gate_income,
		"bonus": result_bonus,
		"wages": wages_paid
	}
	finance_updated.emit(get_balance())

func _round_count(fixtures: Array) -> int:
	var maximum := 0
	for fixture_variant in fixtures:
		var fixture_row: Dictionary = fixture_variant
		maximum = maxi(maximum, int(fixture_row.get("round", 0)))
	return maximum

func _finish_season() -> void:
	var standings := get_standings()
	if standings.size() > 0:
		career["season_summary"] = {
			"champion": str(standings[0].get("club_name", "")),
			"position": _user_position(standings),
			"season": get_season()
		}
		var history: Array = career.get("history", [])
		history.push_back("Temporada %d • Campeão: %s • Sua colocação: %dº" % [
			get_season(), str(standings[0].get("club_name", "")), _user_position(standings)
		])
		career["history"] = history
	_evolve_players()
	career["season"] = get_season() + 1
	career["current_round"] = 1
	# Nova temporada mantém os mesmos participantes e reinicia a tabela.
	var clubs := database.get_clubs_for_league(int(career["league_id"]))
	var standings_new: Dictionary = {}
	for club in clubs:
		var club_id := int(club["id"])
		standings_new[str(club_id)] = {
			"club_id": club_id,
			"club_name": str(club["name"]),
			"played": 0, "wins": 0, "draws": 0, "losses": 0,
			"goals_for": 0, "goals_against": 0, "points": 0
		}
	career["standings"] = standings_new
	career["fixtures"] = _create_fixtures(clubs, int(career["league_id"]))

func _user_position(standings: Array) -> int:
	for i in range(standings.size()):
		if int(standings[i].get("club_id", -1)) == get_current_club_id():
			return i + 1
	return 0

func _evolve_players() -> int:
	if database == null:
		return 0
	var improved := 0
	for player in database.get_roster(get_current_club_id()):
		var overall := int(player.get("overall", 50))
		var potential := int(player.get("potential", overall))
		var age := int(player.get("age", 25))
		if overall >= potential:
			continue
		var chance := 0.22 + float(potential - overall) * 0.025
		if age > 28:
			chance *= 0.45
		if _rng.randf() < chance:
			if database.update_player_rating(int(player["id"]), overall + 1):
				improved += 1
	return improved

func train_squad() -> Dictionary:
	if not has_career():
		return {"ok": false, "error": "Inicie uma carreira primeiro."}
	var training_cost := 25000
	if get_balance() < training_cost:
		return {"ok": false, "error": "Saldo insuficiente para o treino."}
	var improved := _evolve_players()
	career["club_balance"] = get_balance() - training_cost
	save_career()
	career_updated.emit()
	return {"ok": true, "improved": improved, "cost": training_cost}

func buy_player(player_id: int) -> Dictionary:
	if not has_career() or database == null:
		return {"ok": false, "error": "Carreira não iniciada."}
	var player := database.get_player_by_id(player_id)
	if player.is_empty():
		return {"ok": false, "error": "Jogador não encontrado."}
	if int(player["club_id"]) == get_current_club_id():
		return {"ok": false, "error": "Este jogador já pertence ao seu clube."}
	var fee := int(player["market_value"])
	if fee > get_balance():
		return {"ok": false, "error": "Saldo insuficiente para contratar este jogador."}
	var roster := database.get_roster(get_current_club_id())
	var wage_total := 0
	for existing in roster:
		wage_total += int(existing.get("weekly_salary", 0))
	if wage_total + int(player["weekly_salary"]) > int(career.get("wage_limit", 50000)):
		return {"ok": false, "error": "O limite salarial do clube seria ultrapassado."}
	if not database.transfer_player(player_id, get_current_club_id()):
		return {"ok": false, "error": "Não foi possível concluir a transferência."}
	career["club_balance"] = get_balance() - fee
	career["last_transfer"] = "Contratou %s por %s." % [player["name"], _money(fee)]
	save_career()
	career_updated.emit()
	return {"ok": true, "player": player, "fee": fee}

func sell_player(player_id: int) -> Dictionary:
	if not has_career() or database == null:
		return {"ok": false, "error": "Carreira não iniciada."}
	var player := database.get_player_by_id(player_id)
	if player.is_empty() or int(player["club_id"]) != get_current_club_id():
		return {"ok": false, "error": "Jogador não pertence ao seu clube."}
	if database.get_roster(get_current_club_id()).size() <= 11:
		return {"ok": false, "error": "Mantenha pelo menos 11 jogadores no elenco."}
	var clubs := database.get_clubs_for_league(int(career["league_id"]))
	var destination := -1
	for club in clubs:
		if int(club["id"]) != get_current_club_id():
			destination = int(club["id"])
			break
	if destination < 0:
		return {"ok": false, "error": "Não há outro clube disponível nesta divisão."}
	var fee := int(float(player["market_value"]) * 0.82)
	if not database.transfer_player(player_id, destination):
		return {"ok": false, "error": "Não foi possível concluir a venda."}
	career["club_balance"] = get_balance() + fee
	career["last_transfer"] = "Vendeu %s por %s." % [player["name"], _money(fee)]
	save_career()
	career_updated.emit()
	return {"ok": true, "player": player, "fee": fee}

func save_career() -> bool:
	if career.is_empty():
		return false
	var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if file == null:
		return false
	file.store_string(JSON.stringify(career))
	file.close()
	if database != null:
		database.save_database()
	return true

func load_career() -> Dictionary:
	if not FileAccess.file_exists(SAVE_PATH):
		return {"ok": false, "error": "Nenhum save encontrado."}
	var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if file == null:
		return {"ok": false, "error": "Não foi possível ler o save."}
	var parsed: Variant = JSON.parse_string(file.get_as_text())
	file.close()
	if not parsed is Dictionary or not parsed.has("club_id"):
		return {"ok": false, "error": "Save inválido."}
	career = parsed
	career_updated.emit()
	return {"ok": true, "career": career.duplicate(true)}

func _money(value: int) -> String:
	var digits := str(maxi(0, value))
	var groups: Array[String] = []
	while digits.length() > 3:
		groups.push_front(digits.substr(digits.length() - 3, 3))
		digits = digits.substr(0, digits.length() - 3)
	groups.push_front(digits)
	var formatted := groups[0]
	for i in range(1, groups.size()):
		formatted += "." + groups[i]
	return "R$ " + formatted
