extends Control

const DATABASE_SCRIPT = preload("res://scripts/data/GeradorBancoDados.gd")
const CAREER_SCRIPT = preload("res://scripts/career/career_manager.gd")
const MATCH_SCRIPT = preload("res://scripts/match/match_engine.gd")
const CLASSIFICATION_SCENE = preload("res://scenes/menu_classificacao.tscn")
const FIELD_SCENE = preload("res://scenes/campo_controle.tscn")
const GSC_SYSTEMS_SCRIPT = preload("res://scripts/systems/gsc_world_systems.gd")
const PLAYER_PORTRAIT_SCRIPT = preload("res://scripts/presentation/player_portrait.gd")
const TOURNAMENT_SCRIPT = preload("res://scripts/competition/custom_tournament_manager.gd")

var database: GeradorBancoDados
var career_manager: CareerManager
var gsc_systems: GSCWorldSystems
var tournament_manager: GSCCustomTournamentManager
var match_engine: MatchEngine
var manual_field: CampoControle

var main_column: VBoxContainer
var content: VBoxContainer
var status_label: Label
var club_search: LineEdit
var club_select: OptionButton
var match_score_label: Label
var match_log_label: RichTextLabel
var next_minute_button: Button

var home_team_snapshot: Dictionary = {}
var away_team_snapshot: Dictionary = {}
var match_state: Dictionary = {}
var active_fixture: Dictionary = {}
var match_log := ""

func _ready() -> void:
	_build_shell()
	_initialize_game()

func _build_shell() -> void:
	var background := ColorRect.new()
	background.color = Color("#101a20")
	background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(background)

	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.add_theme_constant_override("margin_left", 28)
	margin.add_theme_constant_override("margin_right", 28)
	margin.add_theme_constant_override("margin_top", 22)
	margin.add_theme_constant_override("margin_bottom", 18)
	add_child(margin)

	main_column = VBoxContainer.new()
	main_column.add_theme_constant_override("separation", 12)
	margin.add_child(main_column)

	var title := Label.new()
	title.text = "GLOBAL SOCCER CHAMPS"
	title.add_theme_font_size_override("font_size", 32)
	title.add_theme_color_override("font_color", Color("#f3f7f4"))
	main_column.add_child(title)

	var subtitle := Label.new()
	subtitle.text = "GSC • Carreira de técnico e atleta • Mercado • Academia • Partidas por toque"
	subtitle.add_theme_color_override("font_color", Color("#a8c4b4"))
	main_column.add_child(subtitle)

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	main_column.add_child(scroll)

	content = VBoxContainer.new()
	content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	content.add_theme_constant_override("separation", 12)
	scroll.add_child(content)

	status_label = Label.new()
	status_label.text = "Preparando o jogo..."
	status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	status_label.add_theme_color_override("font_color", Color("#ffdf91"))
	main_column.add_child(status_label)

func _initialize_game() -> void:
	status_label.text = "Lendo o Data Pack incluído no aplicativo..."
	database = DATABASE_SCRIPT.new() as GeradorBancoDados
	add_child(database)
	database.progresso.connect(_on_database_progress)
	var database_result: Dictionary = await database.initialize_database()
	if not bool(database_result.get("ok", false)):
		status_label.text = "Falha ao iniciar a base: " + str(database_result.get("error", "erro desconhecido"))
		return
	career_manager = CAREER_SCRIPT.new() as CareerManager
	add_child(career_manager)
	career_manager.configure(database)
	match_engine = MATCH_SCRIPT.new() as MatchEngine
	var save_result := career_manager.load_career()
	gsc_systems = GSC_SYSTEMS_SCRIPT.new() as GSCWorldSystems
	add_child(gsc_systems)
	var active_club_id := career_manager.get_current_club_id() if career_manager.has_career() else 0
	var active_club_name := career_manager.get_current_club_name() if career_manager.has_career() else "Sem clube"
	gsc_systems.configure(active_club_id, active_club_name)
	if career_manager.has_career():
		gsc_systems.update_club_context(career_manager.get_balance(), int(career_manager.career.get("wage_limit", 0)), database.get_roster(active_club_id))
	tournament_manager = TOURNAMENT_SCRIPT.new() as GSCCustomTournamentManager
	add_child(tournament_manager)
	if bool(save_result.get("ok", false)):
		status_label.text = "Carreira carregada automaticamente. Bem-vindo ao GSC."
	else:
		status_label.text = str(database_result.get("message", "Base pronta."))
	_show_home()

func _on_database_progress(stage: String, current: int, total: int) -> void:
	status_label.text = "%s — %d / %d" % [stage, current, total]

func _clear_content() -> void:
	for child in content.get_children():
		content.remove_child(child)
		child.queue_free()

func _add_label(parent: Node, caption: String, size: int = 18, color: Color = Color("#edf4ef")) -> Label:
	var label := Label.new()
	label.text = caption
	label.add_theme_font_size_override("font_size", size)
	label.add_theme_color_override("font_color", color)
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	parent.add_child(label)
	return label

func _add_button(parent: Node, caption: String, callback: Callable) -> Button:
	var button := Button.new()
	button.text = caption
	button.custom_minimum_size = Vector2(0, 48)
	button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	button.pressed.connect(callback)
	parent.add_child(button)
	return button

func _show_home() -> void:
	_clear_content()
	if database == null:
		return
	var meta: Dictionary = database.database_data.get("meta", {})
	_add_label(content, "GLOBAL SOCCER CHAMPS • CENTRAL DO JOGO", 21, Color("#9edab7"))
	_add_label(content, "%d clubes • %d jogadores • %d competições • %d estádios" % [
		int(meta.get("clubs_count", 0)),
		int(meta.get("players_count", 0)),
		int(meta.get("competitions_count", 0)),
		int(meta.get("stadiums_count", 0))
	], 16)
	_add_label(content, "Nota: o Data Pack fornece IDs e nomes. Atributos, vínculo jogador-clube e aparência são gerados pelo GSC quando não há dados de origem.", 14, Color("#eacb86"))
	if gsc_systems != null:
		var athlete: Dictionary = gsc_systems.state.get("player_career", {})
		_add_label(content, "BUX %d  •  ENERGIA %d%%  •  KITS MÉDICOS %d  •  MOEDA %s" % [
			gsc_systems.get_bux(),
			int(gsc_systems.state.get("energy", 100)),
			int(gsc_systems.state.get("medical_kits", 0)),
			str(gsc_systems.state.get("currency", "BRL"))
		], 16, Color("#ffe08a"))
		if not athlete.is_empty():
			_add_label(content, "CARREIRA DE ATLETA: %s • GER %d • %s" % [
				str(athlete.get("name", "Atleta")),
				gsc_systems.get_dynamic_overall(),
				str(athlete.get("club_name", "Sem clube"))
			], 16, Color("#9ec8ff"))

	if career_manager != null and career_manager.has_career():
		_add_label(content, "SUA CARREIRA", 21, Color("#9edab7"))
		var club_logo := TextureRect.new()
		club_logo.custom_minimum_size = Vector2(92, 92)
		club_logo.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		club_logo.texture = database.get_logo_texture(career_manager.get_current_club_id())
		content.add_child(club_logo)
		_add_label(content, "%s • Divisão %02d • Temporada %d" % [career_manager.get_current_club_name(), int(career_manager.career.get("league_id", 1)), career_manager.get_season()], 19)
		_add_label(content, "Saldo: %s" % _money(career_manager.get_balance()), 17, Color("#ffe08a"))
		_add_label(content, "Último resultado: " + str(career_manager.career.get("last_result", "Nenhuma partida")), 15)
		_add_button(content, "JOGAR PRÓXIMA PARTIDA", _start_match)
		_add_button(content, "CLASSIFICAÇÃO", _show_classification)
		_add_button(content, "MERCADO DE TRANSFERÊNCIAS", _show_market)
		_add_button(content, "MEU ELENCO", _show_squad)
		_add_button(content, "TREINAR ELENCO", _train_squad)
		_add_button(content, "CARREIRA DE JOGADOR", _show_player_career)
		_add_button(content, "ACADEMIA & OLHEIROS", _show_academy)
		_add_button(content, "DIRETORIA & REDES SOCIAIS", _show_club_office)
		_add_button(content, "TÁTICAS & FORMAÇÕES", _show_tactics)
		_add_button(content, "TORNEIOS PERSONALIZADOS", _show_custom_tournaments)
		_add_button(content, "SALA DE TROFÉUS", _show_trophy_room)
		_add_button(content, "LOJA GRATUITA & CONFIGURAÇÕES", _show_free_shop)
		_add_button(content, "SALVAR CARREIRA", _save_career)
	else:
		_add_label(content, "ESCOLHA SEU CLUBE", 21, Color("#9edab7"))
		club_search = LineEdit.new()
		club_search.placeholder_text = "Digite o nome do clube para pesquisar..."
		club_search.custom_minimum_size.y = 48
		club_search.text_changed.connect(_refresh_club_options)
		content.add_child(club_search)
		club_select = OptionButton.new()
		club_select.custom_minimum_size.y = 48
		content.add_child(club_select)
		_refresh_club_options("")
		_add_button(content, "COMEÇAR CARREIRA DE TÉCNICO", _create_career)
		_add_button(content, "CARREIRA DE JOGADOR (SEM CLUBE)", _show_player_career)
		_add_button(content, "TORNEIOS PERSONALIZADOS", _show_custom_tournaments)
		_add_button(content, "LOJA GRATUITA & CONFIGURAÇÕES", _show_free_shop)

func _refresh_club_options(query: String) -> void:
	if club_select == null or database == null:
		return
	club_select.clear()
	var clubs := database.search_clubs(query, 60)
	for club in clubs:
		club_select.add_item(str(club.get("name", "Clube")), int(club.get("id", 0)))
	if clubs.is_empty():
		club_select.add_item("Nenhum clube encontrado", -1)

func _create_career() -> void:
	if club_select == null or club_select.item_count == 0:
		status_label.text = "Pesquise e selecione um clube."
		return
	var selected_id := club_select.get_selected_id()
	if selected_id <= 0:
		status_label.text = "Selecione um clube válido."
		return
	var result := career_manager.start_career(selected_id)
	if not bool(result.get("ok", false)):
		status_label.text = str(result.get("error", "Não foi possível iniciar a carreira."))
		return
	if gsc_systems != null:
		gsc_systems.configure(selected_id, career_manager.get_current_club_name())
		gsc_systems.update_club_context(career_manager.get_balance(), int(career_manager.career.get("wage_limit", 0)), database.get_roster(career_manager.get_current_club_id()))
	status_label.text = "Carreira criada com %d clubes e %d jogos no calendário." % [int(result.get("teams", 0)), int(result.get("fixtures", 0))]
	_show_home()

func _show_classification() -> void:
	var classification := CLASSIFICATION_SCENE.instantiate() as MenuClassificacao
	classification.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(classification)
	classification.set_career_manager(career_manager)

func _show_market() -> void:
	_clear_content()
	_add_label(content, "MERCADO DE TRANSFERÊNCIAS", 25, Color("#9edab7"))
	_add_label(content, "Saldo: %s • Limite salarial semanal: %s" % [_money(career_manager.get_balance()), _money(int(career_manager.career.get("wage_limit", 0)))], 16)
	var players := database.get_market_players(career_manager.get_current_club_id(), 24)
	for player in players:
		var card := VBoxContainer.new()
		card.add_theme_constant_override("separation", 3)
		content.add_child(card)
		var player_row := HBoxContainer.new()
		card.add_child(player_row)
		var avatar = PLAYER_PORTRAIT_SCRIPT.new()
		avatar.custom_minimum_size = Vector2(70, 82)
		var portrait_data: Dictionary = player.duplicate(true)
		portrait_data["appearance"] = gsc_systems.make_appearance(int(player.get("id", 1)))
		avatar.set_player_data(portrait_data)
		player_row.add_child(avatar)
		var player_info := VBoxContainer.new()
		player_info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		player_row.add_child(player_info)
		_add_label(player_info, "%s  •  %s  •  GER %d  •  %d anos" % [str(player["name"]), str(player["position"]), int(player["overall"]), int(player["age"])], 16)
		_add_label(player_info, "Potencial %d • Valor %s • Salário/semana %s" % [int(player["potential"]), _money(int(player["market_value"])), _money(int(player["weekly_salary"]))], 14, Color("#b7c8bd"))
		var player_id := int(player["id"])
		_add_button(card, "CONTRATAR", func() -> void: _buy_player(player_id))
		var separator := HSeparator.new()
		content.add_child(separator)
	_add_button(content, "VOLTAR", _show_home)

func _buy_player(player_id: int) -> void:
	var result := career_manager.buy_player(player_id)
	status_label.text = "Contratação concluída." if bool(result.get("ok", false)) else str(result.get("error", "Falha na contratação."))
	_show_market()

func _show_squad() -> void:
	_clear_content()
	_add_label(content, "MEU ELENCO", 25, Color("#9edab7"))
	_add_label(content, "Saldo: %s" % _money(career_manager.get_balance()), 16)
	var roster := database.get_roster(career_manager.get_current_club_id())
	roster.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
		return int(a["overall"]) > int(b["overall"])
	)
	for player in roster:
		var card := VBoxContainer.new()
		card.add_theme_constant_override("separation", 3)
		content.add_child(card)
		var player_row := HBoxContainer.new()
		card.add_child(player_row)
		var avatar = PLAYER_PORTRAIT_SCRIPT.new()
		avatar.custom_minimum_size = Vector2(70, 82)
		var portrait_data: Dictionary = player.duplicate(true)
		portrait_data["appearance"] = gsc_systems.make_appearance(int(player.get("id", 1)))
		avatar.set_player_data(portrait_data)
		player_row.add_child(avatar)
		var player_info := VBoxContainer.new()
		player_info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		player_row.add_child(player_info)
		_add_label(player_info, "%s • %s • GER %d • %d anos" % [str(player["name"]), str(player["position"]), int(player["overall"]), int(player["age"])], 16)
		_add_label(player_info, "Potencial %d • Salário/semana %s" % [int(player["potential"]), _money(int(player["weekly_salary"]))], 14, Color("#b7c8bd"))
		var player_id := int(player["id"])
		_add_button(card, "VENDER POR %s" % _money(int(float(player["market_value"]) * 0.82)), func() -> void: _sell_player(player_id))
		content.add_child(HSeparator.new())
	_add_button(content, "VOLTAR", _show_home)

func _sell_player(player_id: int) -> void:
	var result := career_manager.sell_player(player_id)
	status_label.text = "Venda concluída." if bool(result.get("ok", false)) else str(result.get("error", "Falha na venda."))
	_show_squad()

func _train_squad() -> void:
	var result := career_manager.train_squad()
	if bool(result.get("ok", false)):
		status_label.text = "Treino finalizado. %d jogador(es) evoluíram. Custo: %s" % [int(result.get("improved", 0)), _money(int(result.get("cost", 0)))]
	else:
		status_label.text = str(result.get("error", "Não foi possível treinar."))
	_show_home()

func _save_career() -> void:
	status_label.text = "Carreira salva." if career_manager.save_career() else "Não foi possível salvar a carreira."

func _start_match() -> void:
	active_fixture = career_manager.get_next_fixture()
	if active_fixture.is_empty():
		status_label.text = "Não há partidas pendentes."
		return
	var home_id := int(active_fixture["home_club_id"])
	var away_id := int(active_fixture["away_club_id"])
	home_team_snapshot = career_manager.make_team_snapshot(home_id)
	away_team_snapshot = career_manager.make_team_snapshot(away_id)
	if gsc_systems != null and home_id == career_manager.get_current_club_id():
		home_team_snapshot = gsc_systems.apply_tactical_modifiers(home_team_snapshot, database.get_roster(home_id))
	if gsc_systems != null and away_id == career_manager.get_current_club_id():
		away_team_snapshot = gsc_systems.apply_tactical_modifiers(away_team_snapshot, database.get_roster(away_id))
	var user_energy := int(gsc_systems.state.get("energy", 100)) if gsc_systems != null else 100
	if user_energy < 35:
		for sector in ["attack", "midfield", "defence"]:
			home_team_snapshot[sector] = maxf(20.0, float(home_team_snapshot.get(sector, 50.0)) - 5.0) if home_id == career_manager.get_current_club_id() else home_team_snapshot[sector]
			away_team_snapshot[sector] = maxf(20.0, float(away_team_snapshot.get(sector, 50.0)) - 5.0) if away_id == career_manager.get_current_club_id() else away_team_snapshot[sector]
	match_state = match_engine.create_match(home_team_snapshot, away_team_snapshot, career_manager.get_current_club_id(), int(active_fixture["id"]))
	match_log = "Apito inicial! %s x %s" % [str(home_team_snapshot["name"]), str(away_team_snapshot["name"])]
	_show_match()

func _show_match() -> void:
	_clear_content()
	_add_label(content, "PARTIDA • RODADA %d" % int(active_fixture.get("round", 1)), 23, Color("#9edab7"))
	var match_badges := HBoxContainer.new()
	match_badges.alignment = BoxContainer.ALIGNMENT_CENTER
	content.add_child(match_badges)
	var home_badge := TextureRect.new()
	home_badge.custom_minimum_size = Vector2(58, 58)
	home_badge.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	home_badge.texture = database.get_logo_texture(int(active_fixture.get("home_club_id", 0)))
	match_badges.add_child(home_badge)
	var away_badge := TextureRect.new()
	away_badge.custom_minimum_size = Vector2(58, 58)
	away_badge.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	away_badge.texture = database.get_logo_texture(int(active_fixture.get("away_club_id", 0)))
	match_badges.add_child(away_badge)
	match_score_label = _add_label(content, _score_text(), 26, Color("#ffe08a"))
	match_log_label = RichTextLabel.new()
	match_log_label.bbcode_enabled = false
	match_log_label.fit_content = true
	match_log_label.custom_minimum_size.y = 150
	match_log_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	match_log_label.text = match_log
	content.add_child(match_log_label)
	next_minute_button = _add_button(content, "AVANÇAR 1 MINUTO", _advance_match_minute)
	_add_button(content, "VOLTAR À CARREIRA", _show_home)

func _score_text() -> String:
	return "%s   %d  x  %d   %s   •   %d'" % [
		str(home_team_snapshot.get("name", "Casa")),
		int(match_state.get("home_goals", 0)),
		int(match_state.get("away_goals", 0)),
		str(away_team_snapshot.get("name", "Fora")),
		int(match_state.get("minute", 0))
	]

func _advance_match_minute() -> void:
	if bool(match_state.get("finished", false)) or bool(match_state.get("manual_pending", false)):
		return
	var result := match_engine.simulate_minute(home_team_snapshot, away_team_snapshot, match_state, career_manager.get_current_club_id())
	match_state = result["state"]
	var event: Dictionary = result["event"]
	var event_type := str(event.get("type", ""))
	if event_type == "manual_chance":
		_append_match_log("%d' — %s" % [int(match_state["minute"]), str(event.get("text", "Chance!"))])
		_open_manual_field()
	elif event_type == "finished":
		_append_match_log("90' — Fim de jogo.")
		_finish_match()
	elif not event.is_empty():
		_append_match_log("%d' — %s" % [int(match_state["minute"]), str(event.get("text", "Lance da partida."))])
	else:
		_append_match_log("%d' — Jogo em andamento." % int(match_state["minute"]))
	match_score_label.text = _score_text()

func _open_manual_field() -> void:
	if is_instance_valid(manual_field):
		return
	manual_field = FIELD_SCENE.instantiate() as CampoControle
	manual_field.action_requested.connect(_on_manual_action)
	add_child(manual_field)
	manual_field.z_index = 100

func _on_manual_action(action: Dictionary) -> void:
	var action_type := str(action.get("type", ""))
	if action_type == "pass":
		_append_match_log("Passe no controle manual. A jogada continua.")
		return
	if action_type != "shoot":
		return
	var user_is_home := int(match_state.get("home_team_id", -1)) == career_manager.get_current_club_id()
	var attacker_roster := database.get_roster(career_manager.get_current_club_id())
	var shot_skill := 55.0
	var attack_count := 0
	var attack_total := 0.0
	for player in attacker_roster:
		if str(player.get("position", "")) == "ATT":
			attack_total += float(player.get("overall", 55))
			attack_count += 1
	if attack_count > 0:
		shot_skill = attack_total / float(attack_count)
	var keeper_skill := float(away_team_snapshot.get("goalkeeper", 55.0)) if user_is_home else float(home_team_snapshot.get("goalkeeper", 55.0))
	var power := float(action.get("power", 0.65))
	var shot_result := match_engine.resolve_manual_shot(
		match_state,
		float(match_state.get("pending_quality", 0.45)),
		shot_skill,
		keeper_skill,
		user_is_home,
		power
	)
	match_state = shot_result["state"]
	var event: Dictionary = shot_result["event"]
	var is_goal := bool(event.get("goal", false))
	if is_instance_valid(manual_field):
		manual_field.show_shot_result(is_goal, str(event.get("text", "Finalização.")))
	await get_tree().create_timer(1.35).timeout
	if is_instance_valid(manual_field):
		manual_field.queue_free()
	manual_field = null
	_append_match_log("%d' — %s" % [int(match_state["minute"]), str(event.get("text", "Finalização."))])
	match_score_label.text = _score_text()
	if next_minute_button != null:
		next_minute_button.disabled = false

func _append_match_log(line: String) -> void:
	match_log += "\n" + line
	if match_log_label != null:
		match_log_label.text = match_log

func _finish_match() -> void:
	if next_minute_button != null:
		next_minute_button.disabled = true
	var result := career_manager.register_match_result(int(active_fixture.get("id", -1)), match_state)
	if bool(result.get("ok", false)):
		_append_match_log("Resultado salvo na classificação. Saldo: %s" % _money(int(result.get("balance", 0))))
		if gsc_systems != null:
			var user_is_home := int(active_fixture.get("home_club_id", -1)) == career_manager.get_current_club_id()
			var user_goals := int(match_state.get("home_goals", 0)) if user_is_home else int(match_state.get("away_goals", 0))
			var opponent_goals := int(match_state.get("away_goals", 0)) if user_is_home else int(match_state.get("home_goals", 0))
			gsc_systems.state["energy"] = maxi(0, int(gsc_systems.state.get("energy", 100)) - 18)
			if user_goals > opponent_goals:
				gsc_systems.earn_bux(5, "vitória no campeonato")
			elif user_goals == opponent_goals:
				gsc_systems.earn_bux(2, "empate no campeonato")
			var season_summary: Dictionary = career_manager.career.get("season_summary", {})
			var finished_season := int(season_summary.get("season", 0))
			var rewarded_season := int(gsc_systems.state.get("last_season_rewarded", -1))
			if finished_season > 0 and finished_season != rewarded_season:
				if str(season_summary.get("champion", "")) == career_manager.get_current_club_name():
					gsc_systems.earn_bux(50, "título da liga")
				gsc_systems.state["last_season_rewarded"] = finished_season
			gsc_systems.save_state()
	else:
		_append_match_log(str(result.get("error", "Falha ao registrar o resultado.")))
	_add_button(content, "VOLTAR AO MENU DA CARREIRA", _show_home)


func _show_player_career() -> void:
	_clear_content()
	_add_label(content, "CARREIRA DE ATLETA", 25, Color("#9edab7"))
	_add_label(content, "Crie um jogador, treine, conquiste minutos e construa sua própria trajetória.", 16)
	var athlete: Dictionary = gsc_systems.state.get("player_career", {})
	if athlete.is_empty():
		var name_input := LineEdit.new()
		name_input.placeholder_text = "Nome do seu jogador"
		name_input.custom_minimum_size.y = 48
		content.add_child(name_input)
		var position_select := OptionButton.new()
		for pos in ["ATA", "PE", "PD", "MEI", "MC", "VOL", "ZAG", "LE", "LD", "GOL"]:
			position_select.add_item(pos)
		content.add_child(position_select)
		var player_club_select := OptionButton.new()
		player_club_select.add_item("Agente livre", 0)
		for club in database.search_clubs("", 60):
			player_club_select.add_item(str(club.get("name", "Clube")), int(club.get("id", 0)))
		if career_manager.has_career():
			_add_label(content, "O atleta começará no clube da sua carreira de técnico.", 14, Color("#b8d5c7"))
			player_club_select.disabled = true
		else:
			_add_label(content, "Escolha um clube inicial ou comece como agente livre.", 14)
		content.add_child(player_club_select)
		_add_button(content, "CRIAR MEU ATLETA", func() -> void:
			var club_id := career_manager.get_current_club_id() if career_manager.has_career() else player_club_select.get_selected_id()
			var club_name := career_manager.get_current_club_name() if career_manager.has_career() else "Agente livre"
			if not career_manager.has_career() and club_id > 0:
				club_name = str(database.get_club(club_id).get("name", "Clube"))
			var result := gsc_systems.create_player_career(name_input.text, position_select.get_item_text(position_select.get_selected()), club_id, club_name)
			if bool(result.get("ok", false)) and club_id > 0:
				var created_player: Dictionary = result.get("player", {})
				database.add_generated_player(created_player, club_id)
			status_label.text = str(result.get("message", "Carreira de atleta criada.")) if not bool(result.get("ok", false)) else "Seu atleta foi criado!"
			_show_player_career()
		)
	else:
		var portrait = PLAYER_PORTRAIT_SCRIPT.new()
		portrait.custom_minimum_size = Vector2(140, 155)
		portrait.set_player_data(athlete)
		content.add_child(portrait)
		_add_label(content, "%s • %s • %d anos" % [
			str(athlete.get("name", "Atleta")),
			str(athlete.get("position", "ATA")),
			int(athlete.get("age", 17))
		], 21, Color("#f2d18c"))
		_add_label(content, "%s • GER base %d • GER dinâmico %d • Potencial %d" % [
			str(athlete.get("club_name", "Agente livre")),
			int(athlete.get("overall", 52)),
			gsc_systems.get_dynamic_overall(),
			int(athlete.get("potential", 88))
		], 16)
		_add_label(content, "Forma %d • Moral %d • Condição %d • Energia %d" % [
			int(athlete.get("form", 50)), int(athlete.get("morale", 65)),
			int(athlete.get("fitness", 100)), int(athlete.get("energy", 100))
		], 15, Color("#b8d5c7"))
		if int(athlete.get("injury_days", 0)) > 0:
			_add_label(content, "LESIONADO • Recuperação estimada: %d dia(s)" % int(athlete.get("injury_days", 0)), 15, Color("#ff9b8b"))
		_add_label(content, "Partidas %d • Minutos %d • Gols %d • Assistências %d • XP %d/100" % [
			int(athlete.get("appearances", 0)), int(athlete.get("minutes", 0)),
			int(athlete.get("goals", 0)), int(athlete.get("assists", 0)),
			int(athlete.get("xp", 0))
		], 15)
		_add_label(content, "Rivalidade: %s • Contrato: %d anos" % [
			str(athlete.get("rival_name", "Rival em definição")), int(athlete.get("contract_years", 3))
		], 14, Color("#a8c4b4"))
		for training in ["Finalização", "Passe", "Velocidade", "Físico"]:
			_add_button(content, "TREINAR: " + training, _train_gsc_player.bind(training))
		_add_button(content, "DISPUTAR PARTIDA SIMULADA", _simulate_gsc_player_match)
		_add_button(content, "RESGATAR RECOMPENSA DIÁRIA", _claim_gsc_daily)
	_add_button(content, "VOLTAR", _show_home)

func _train_gsc_player(training: String) -> void:
	var result := gsc_systems.train_player_career(training)
	if bool(result.get("ok", false)):
		var athlete: Dictionary = result.get("player", {})
		database.update_player_rating(int(athlete.get("id", -1)), int(athlete.get("overall", 50)))
		status_label.text = "Treino concluído: +%d XP." % int(result.get("xp", 0))
	else:
		status_label.text = str(result.get("message", "Treino registrado."))
	_show_player_career()

func _simulate_gsc_player_match() -> void:
	var result := gsc_systems.simulate_player_appearance()
	if bool(result.get("ok", false)):
		status_label.text = "Partida concluída: %d gol(s), %d assistência(s)." % [int(result.get("goals", 0)), int(result.get("assists", 0))]
	else:
		status_label.text = str(result.get("message", "Não foi possível simular a partida."))
	_show_player_career()

func _claim_gsc_daily() -> void:
	var result := gsc_systems.claim_daily_reward()
	status_label.text = str(result.get("message", "Recompensa processada."))
	_show_player_career()

func _show_club_office() -> void:
	_clear_content()
	_add_label(content, "DIRETORIA • FINANÇAS • REDES SOCIAIS", 23, Color("#9edab7"))
	var finance: Dictionary = gsc_systems.state.get("club_finance", {})
	var debt := int(finance.get("debt", 0))
	_add_label(content, "Situação: " + gsc_systems.get_crisis_label(), 18, Color("#ffe08a"))
	_add_label(content, "Dívidas: %s • Estabilidade: %d/100" % [gsc_systems.format_money(debt), int(finance.get("financial_stability", 75))], 16)
	_add_label(content, "Confiança da diretoria: %d • Torcida: %d • Vestiário: %d" % [
		int(finance.get("board_confidence", 70)),
		int(finance.get("fan_trust", 65)),
		int(finance.get("dressing_room", 70))
	], 15)
	if career_manager.has_career():
		_add_label(content, "Saldo disponível: " + _money(career_manager.get_balance()), 16)
		_add_button(content, "AMORTIZAR " + _money(100000) + " DA DÍVIDA", _repay_gsc_debt)
		_add_button(content, "SOLICITAR EMPRÉSTIMO EMERGENCIAL", _take_gsc_loan)
	else:
		_add_label(content, "Inicie uma carreira de técnico para movimentar o caixa do clube.", 14, Color("#eacb86"))
	_add_label(content, "DECISÕES DA DIRETORIA E DA IMPRENSA", 18, Color("#9edab7"))
	_add_button(content, "ENTREVISTA TRANSPARENTE COM A TORCIDA", func() -> void: _social_decision("honest"))
	_add_button(content, "PROMETER RESULTADOS À DIRETORIA", func() -> void: _social_decision("promise"))
	_add_button(content, "CONVERSAR COM O VESTIÁRIO", func() -> void: _social_decision("locker"))
	_add_label(content, "FEED SOCIAL DO GSC", 18, Color("#9edab7"))
	for post in gsc_systems.get_social_feed():
		_add_label(content, "DIA %d • %s\n%s" % [int(post.get("day", 1)), str(post.get("source", "GSC")), str(post.get("text", ""))], 14)
	_add_button(content, "AVANÇAR UM DIA", _advance_gsc_day)
	_add_button(content, "VOLTAR", _show_home)

func _social_decision(choice: String) -> void:
	var result := gsc_systems.resolve_social_decision(choice)
	status_label.text = str(result.get("message", "Decisão registrada."))
	_show_club_office()

func _advance_gsc_day() -> void:
	var result := gsc_systems.advance_day()
	status_label.text = "Dia %d. Energia recuperada para %d%%." % [int(result.get("day", 1)), int(result.get("energy", 100))]
	if career_manager.has_career():
		gsc_systems.update_club_context(career_manager.get_balance(), int(career_manager.career.get("wage_limit", 0)), database.get_roster(career_manager.get_current_club_id()))
	_show_club_office()

func _repay_gsc_debt() -> void:
	if not career_manager.has_career():
		status_label.text = "Inicie uma carreira de técnico primeiro."
		return
	var result := gsc_systems.repay_debt(career_manager.get_balance(), 100000)
	if bool(result.get("ok", false)):
		_spend_club_balance(int(result.get("amount", 0)))
	status_label.text = str(result.get("message", "Operação concluída."))
	_show_club_office()

func _take_gsc_loan() -> void:
	if not career_manager.has_career():
		status_label.text = "Inicie uma carreira de técnico primeiro."
		return
	var loan_amount := gsc_systems.take_emergency_loan(250000)
	career_manager.career["club_balance"] = career_manager.get_balance() + loan_amount
	career_manager.save_career()
	status_label.text = "Empréstimo de %s recebido. Juros de 8%% registrados como dívida." % _money(loan_amount)
	_show_club_office()

func _spend_club_balance(amount: int) -> bool:
	if not career_manager.has_career() or career_manager.get_balance() < amount:
		return false
	career_manager.career["club_balance"] = career_manager.get_balance() - amount
	career_manager.save_career()
	return true

func _show_academy() -> void:
	_clear_content()
	_add_label(content, "ACADEMIA • CENTRO DE TREINAMENTO • OLHEIROS", 22, Color("#9edab7"))
	var academy: Dictionary = gsc_systems.state.get("academy", {})
	_add_label(content, "Academia %d/20 • Centro de treinamento %d/20 • Olheiros %d/20" % [
		int(academy.get("level", 3)), int(academy.get("facilities", 2)), int(academy.get("scout_level", 1))
	], 16, Color("#ffe08a"))
	_add_label(content, "Academia melhor aumenta a qualidade dos jovens gerados. Centro de treinamento favorece evolução. Olheiros ampliam a precisão das avaliações.", 14)
	if career_manager.has_career():
		_add_button(content, "MELHORAR ACADEMIA", _upgrade_gsc_academy)
		_add_button(content, "MELHORAR CENTRO DE TREINAMENTO", _upgrade_gsc_facilities)
		_add_button(content, "EVOLUIR REDE DE OLHEIROS", _upgrade_gsc_scout)
	_add_button(content, "PROCURAR NOVO TALENTO", _generate_gsc_prospect)
	_add_label(content, "JOVENS OBSERVADOS", 18, Color("#9edab7"))
	for prospect in academy.get("prospects", []):
		var card := HBoxContainer.new()
		content.add_child(card)
		var portrait = PLAYER_PORTRAIT_SCRIPT.new()
		portrait.custom_minimum_size = Vector2(68, 78)
		portrait.set_player_data(prospect)
		card.add_child(portrait)
		var info := VBoxContainer.new()
		info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		card.add_child(info)
		_add_label(info, "%s • %s • %d anos" % [str(prospect.get("name", "Jovem")), str(prospect.get("position", "MID")), int(prospect.get("age", 17))], 14)
		_add_label(info, "GER %d • Potencial %d • %s" % [int(prospect.get("overall", 40)), int(prospect.get("potential", 70)), str(prospect.get("development", "Desenvolvimento"))], 13, Color("#b8d5c7"))
		var prospect_id := int(prospect.get("id", -1))
		_add_button(content, "PROMOVER " + str(prospect.get("name", "JOVEM")), _promote_gsc_prospect.bind(prospect_id))
	_add_button(content, "VOLTAR", _show_home)

func _upgrade_gsc_academy() -> void:
	if not career_manager.has_career(): return
	var result := gsc_systems.upgrade_academy(career_manager.get_balance())
	if bool(result.get("ok", false)): _spend_club_balance(int(result.get("cost", 0)))
	status_label.text = str(result.get("message", "Academia atualizada.")) if not bool(result.get("ok", false)) else "Academia no nível %d/20." % int(result.get("level", 1))
	_show_academy()

func _upgrade_gsc_facilities() -> void:
	if not career_manager.has_career(): return
	var result := gsc_systems.upgrade_facilities(career_manager.get_balance())
	if bool(result.get("ok", false)): _spend_club_balance(int(result.get("cost", 0)))
	status_label.text = str(result.get("message", "Centro atualizado.")) if not bool(result.get("ok", false)) else "Centro de treinamento no nível %d/20." % int(result.get("level", 1))
	_show_academy()

func _upgrade_gsc_scout() -> void:
	if not career_manager.has_career(): return
	var result := gsc_systems.upgrade_scout(career_manager.get_balance())
	if bool(result.get("ok", false)): _spend_club_balance(int(result.get("cost", 0)))
	status_label.text = str(result.get("message", "Olheiros atualizados.")) if not bool(result.get("ok", false)) else "Rede de olheiros no nível %d/20." % int(result.get("level", 1))
	_show_academy()

func _generate_gsc_prospect() -> void:
	var prospect := gsc_systems.generate_academy_prospect()
	status_label.text = "Olheiro encontrou %s, GER %d e potencial %d." % [str(prospect.get("name", "Jovem")), int(prospect.get("overall", 40)), int(prospect.get("potential", 70))]
	_show_academy()

func _promote_gsc_prospect(prospect_id: int) -> void:
	var result := gsc_systems.promote_prospect(prospect_id)
	if bool(result.get("ok", false)) and career_manager.has_career():
		var player: Dictionary = result.get("player", {})
		if database.add_generated_player(player, career_manager.get_current_club_id()):
			status_label.text = str(player.get("name", "Jovem")) + " foi integrado ao elenco principal."
		else:
			status_label.text = "Promovido na academia, mas não foi possível salvar na base local."
	else:
		status_label.text = str(result.get("message", "Inicie uma carreira de técnico para promover ao elenco."))
	_show_academy()

func _show_tactics() -> void:
	_clear_content()
	_add_label(content, "CENTRAL TÁTICA", 24, Color("#9edab7"))
	var tactics: Dictionary = gsc_systems.state.get("tactics", {})
	var formation_select := OptionButton.new()
	for formation in GSCWorldSystems.FORMATIONS:
		formation_select.add_item(str(formation))
	var selected_formation := GSCWorldSystems.FORMATIONS.find(str(tactics.get("formation", "4-3-3")))
	formation_select.select(maxi(0, selected_formation))
	content.add_child(formation_select)
	var mentality_select := OptionButton.new()
	for mentality in ["Defensiva", "Equilibrada", "Ofensiva"]:
		mentality_select.add_item(mentality)
	var selected_mentality := ["Defensiva", "Equilibrada", "Ofensiva"].find(str(tactics.get("mentality", "Equilibrada")))
	mentality_select.select(maxi(0, selected_mentality))
	content.add_child(mentality_select)
	var pressure_select := OptionButton.new()
	for pressure in ["Baixa", "Média", "Alta"]:
		pressure_select.add_item(pressure)
	var selected_pressure := ["Baixa", "Média", "Alta"].find(str(tactics.get("pressure", "Média")))
	pressure_select.select(maxi(0, selected_pressure))
	content.add_child(pressure_select)
	_add_button(content, "SALVAR TÁTICAS", func() -> void:
		gsc_systems.set_tactics(
			formation_select.get_item_text(formation_select.get_selected()),
			mentality_select.get_item_text(mentality_select.get_selected()),
			pressure_select.get_item_text(pressure_select.get_selected())
		)
		status_label.text = "Tática salva."
		_show_tactics()
	)
	if career_manager.has_career():
		var averages := gsc_systems.sector_averages(database.get_roster(career_manager.get_current_club_id()))
		_add_label(content, "Força média calculada — DEF %d • MEI %d • ATA %d" % [
			int(averages["defence"]), int(averages["midfield"]), int(averages["attack"])
		], 16)
	_add_label(content, "Formações: 4-4-2, 4-3-3, 4-2-3-1, 4-5-1, 3-5-2, 3-4-3, 3-2-4-1, 3-3-1-3, 5-3-2, 5-4-1 e outras.", 14)
	_add_button(content, "VOLTAR", _show_home)

func _show_free_shop() -> void:
	_clear_content()
	_add_label(content, "GSC STORE • TUDO PODE SER OBTIDO JOGANDO", 22, Color("#9edab7"))
	_add_label(content, "Bux disponíveis: %d • Energia: %d%% • Kits médicos: %d" % [
		gsc_systems.get_bux(), int(gsc_systems.state.get("energy", 100)), int(gsc_systems.state.get("medical_kits", 0))
	], 16, Color("#ffe08a"))
	var currency_select := OptionButton.new()
	for currency in ["BRL", "USD", "EUR"]:
		currency_select.add_item(currency)
	currency_select.select(["BRL", "USD", "EUR"].find(str(gsc_systems.state.get("currency", "BRL"))))
	content.add_child(currency_select)
	_add_button(content, "SALVAR MOEDA", func() -> void:
		gsc_systems.set_currency(currency_select.get_item_text(currency_select.get_selected()))
		status_label.text = "Moeda alterada."
		_show_free_shop()
	)
	_add_button(content, "RESGATAR 3 BUX GRÁTIS (OBJETIVO DIÁRIO)", _claim_gsc_daily_from_shop)
	_add_button(content, "TROCAR 5 BUX POR 1 KIT MÉDICO", _buy_gsc_medkit)
	_add_button(content, "TROCAR 4 BUX POR 25 DE ENERGIA", _buy_gsc_energy)
	_add_button(content, "USAR KIT MÉDICO", _use_gsc_medkit)
	_add_button(content, "AVANÇAR UM DIA E RECUPERAR ENERGIA", _advance_gsc_day)
	_add_label(content, "Sem compras obrigatórias: Bux e itens são ganhos jogando, com recompensas diárias e objetivos.", 14, Color("#b8d5c7"))
	_add_button(content, "VOLTAR", _show_home)

func _claim_gsc_daily_from_shop() -> void:
	var result := gsc_systems.claim_daily_reward()
	status_label.text = str(result.get("message", "Recompensa processada."))
	_show_free_shop()

func _buy_gsc_medkit() -> void:
	if gsc_systems.get_bux() < 5:
		status_label.text = "Bux insuficientes. Complete objetivos para ganhar Bux grátis."
		_show_free_shop()
		return
	gsc_systems.spend_bux(5)
	gsc_systems.state["medical_kits"] = int(gsc_systems.state.get("medical_kits", 0)) + 1
	gsc_systems.save_state()
	status_label.text = "Kit médico resgatado sem pagamento real."
	_show_free_shop()

func _buy_gsc_energy() -> void:
	if gsc_systems.get_bux() < 4:
		status_label.text = "Bux insuficientes. Complete objetivos para ganhar Bux grátis."
		_show_free_shop()
		return
	gsc_systems.spend_bux(4)
	gsc_systems.state["energy"] = mini(100, int(gsc_systems.state.get("energy", 100)) + 25)
	gsc_systems.save_state()
	status_label.text = "Energia recuperada em 25 pontos."
	_show_free_shop()

func _use_gsc_medkit() -> void:
	var result := gsc_systems.use_medical_kit()
	status_label.text = str(result.get("message", "Kit médico utilizado."))
	_show_free_shop()


func _show_custom_tournaments() -> void:
	_clear_content()
	_add_label(content, "TORNEIOS PERSONALIZADOS", 24, Color("#9edab7"))
	_add_label(content, "Selecione clubes abaixo. Liga: 8–32 clubes. Copa mata-mata: 4–16 clubes. Nesta versão, a criação e o calendário inicial ficam salvos; a simulação das rodadas customizadas é uma próxima expansão.", 15)
	var name_input := LineEdit.new()
	name_input.placeholder_text = "Nome do torneio"
	name_input.custom_minimum_size.y = 48
	content.add_child(name_input)
	var club_list := ItemList.new()
	club_list.select_mode = ItemList.SELECT_MULTI
	club_list.custom_minimum_size.y = 280
	club_list.size_flags_vertical = Control.SIZE_EXPAND_FILL
	for club in database.search_clubs("", 100):
		club_list.add_item(str(club.get("name", "Clube")))
		var item_index := club_list.item_count - 1
		club_list.set_item_metadata(item_index, int(club.get("id", 0)))
	content.add_child(club_list)
	_add_button(content, "CRIAR LIGA DE PONTOS CORRIDOS", func() -> void: _create_custom_tournament("Liga", name_input, club_list))
	_add_button(content, "CRIAR COPA MATA-MATA", func() -> void: _create_custom_tournament("Copa", name_input, club_list))
	_add_label(content, "TORNEIOS SALVOS", 18, Color("#9edab7"))
	for tournament_entry in tournament_manager.get_tournaments():
		_add_label(content, "%s • %s • %d clubes" % [
			str(tournament_entry.get("name", "Torneio")),
			str(tournament_entry.get("format", "Formato")),
			int(tournament_entry.get("club_count", 0))
		], 14)
	_add_button(content, "VOLTAR", _show_home)

func _create_custom_tournament(format: String, name_input: LineEdit, club_list: ItemList) -> void:
	var selected_clubs: Array = []
	for item_index in club_list.get_selected_items():
		selected_clubs.append(int(club_list.get_item_metadata(item_index)))
	var result: Dictionary
	if format == "Liga":
		result = tournament_manager.create_league(name_input.text, selected_clubs)
	else:
		result = tournament_manager.create_cup(name_input.text, selected_clubs)
	status_label.text = str(result.get("message", "Não foi possível criar o torneio."))
	_show_custom_tournaments()

func _show_trophy_room() -> void:
	_clear_content()
	_add_label(content, "SALA DE TROFÉUS", 24, Color("#9edab7"))
	if career_manager.has_career():
		_add_label(content, "%s • Temporada %d" % [career_manager.get_current_club_name(), career_manager.get_season()], 17)
		var history: Array = career_manager.career.get("history", [])
		var season_summary: Dictionary = career_manager.career.get("season_summary", {})
		if not season_summary.is_empty():
			_add_label(content, "Última campanha: campeão %s • sua posição: %dº" % [
				str(season_summary.get("champion", "—")), int(season_summary.get("position", 0))
			], 15)
		if history.is_empty():
			_add_label(content, "Sua história começa agora. Conquiste títulos para preencher esta sala.", 15)
		else:
			for item in history:
				_add_label(content, str(item), 14)
	else:
		_add_label(content, "Inicie uma carreira de técnico para registrar títulos e campanhas.", 15)
	var achievements: Array = gsc_systems.state.get("achievements", [])
	if achievements.is_empty():
		_add_label(content, "Conquistas: nenhuma desbloqueada ainda.", 14, Color("#b8d5c7"))
	else:
		for achievement in achievements:
			_add_label(content, "🏆 " + str(achievement), 14)
	_add_button(content, "VOLTAR", _show_home)

func _money(value: int) -> String:
	if gsc_systems != null:
		return gsc_systems.format_money(value)
	return "US$ " + str(maxi(0, value))
